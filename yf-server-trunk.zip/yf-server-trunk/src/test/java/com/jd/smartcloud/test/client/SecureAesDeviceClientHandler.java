/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.jd.smartcloud.test.client;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.util.AESUtils;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import org.apache.log4j.Logger;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles a client-side channel.
 */
public class SecureAesDeviceClientHandler extends SimpleChannelInboundHandler<String> {

    private static final Logger logger = Logger.getLogger(
            SecureAesDeviceClientHandler.class.getName());

    @Override
    public void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {
    	logger.info("server response:"+msg);
    	String realMsg = URLDecoder.decode(msg, "UTF-8");
        JSONObject controllInfo = JSON.parseObject(realMsg);
        Integer code = controllInfo.getInteger("code");
        JSONObject att = controllInfo.getJSONObject("attribute");
        Date now = new Date();
        if(code == 1002){

        	String feedId = controllInfo.getString("feed_id");
            long serial = controllInfo.getJSONObject("attribute").getLong("serial");
            String str = "{\"code\":102,\"result\":0,\"controll_resp\":{\"info\":\"Respone OK!\"},\"device\":{\"access_key\": \"6a97d3b4aec51a72944831ac9b4380b4\"},\"attribute\":{\"serial\":"+serial+"}}";
            JSONObject json = JSONObject.parseObject(str);
            
            json.put("timestamp",now.getTime()/1000);
            String data =  AESUtils.encrypt(json.toJSONString(),"6a97d3b4aec51a72944831ac9b4380b4");
        	ctx.writeAndFlush("{\"feed_id\":10000,\"data\":\""+data+"\"}" + "\n");
        	System.out.println("send:"+data);
        }

        if(code == 1004)
        {
        	String deviceStr = "{\"access_key\":\"6a97d3b4aec51a72944831ac9b4380b4\"}";
            JSONObject deviceJson = JSONObject.parseObject(deviceStr);
        	String upData = "[{\"stream_id\":\"light\",\"datapoints\":[{\"value\":\"0\"},{\"at\":\"2014-10-16T00:55:43+0800\",\"value\":\"0\"}]}]";
        	JSONArray upDataJson = JSONArray.parseArray(upData);
        	JSONObject json = new JSONObject();
        	json.put("streams", upDataJson);
        	json.put("code", 104);
        	json.put("device", deviceJson);
        	json.put("timestamp",now.getTime()/1000);
        	json.put("attribute", att);
        	String cryptDataUpdata = AESUtils.encrypt(json.toJSONString(),"6a97d3b4aec51a72944831ac9b4380b4");
        	 JSONObject sendJson = new JSONObject();
             sendJson.put("feed_id", 10000);
             sendJson.put("data", cryptDataUpdata);
            ctx.writeAndFlush(sendJson.toJSONString() + "\n");
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("Unexpected exception from downstream.", cause);
        ctx.close();
    }
    
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
    	super.channelActive(ctx);
    }
}
