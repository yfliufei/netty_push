package com.jd.smartcloud.test.client;

import com.jd.cachecloud.driver.jedis.ShardedXCommands;
import com.jd.smartcloud.eventserver.EventServer;

public class RedisTestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ShardedXCommands redisClient = (ShardedXCommands) EventServer.applicationContext.getBean("redisClient");
		while(true){
			String ip1 = redisClient.get("12143");
			String ip2 = redisClient.get("12142");
			if (null == ip1) {
				System.out.println("there is no 12143");
			} else {
				System.out.println("12143 there is ip:"+ip1);
			}
			
			if (null == ip2) {
				System.out.println("there is no 12142");
			} else {
				System.out.println("12142 there is ip:"+ip2);
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
