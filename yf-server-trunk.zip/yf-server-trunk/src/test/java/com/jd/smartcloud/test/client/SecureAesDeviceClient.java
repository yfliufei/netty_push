/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.jd.smartcloud.test.client;

import java.util.Date;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.util.AESUtils;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

/**
 * Simple SSL chat client modified from {@link TelnetClient}.
 */
public class SecureAesDeviceClient {

    private final String host;
    private final int port;

    public SecureAesDeviceClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void run() throws Exception {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
             .channel(NioSocketChannel.class)
             .handler(new SecureAesDeviceClientInitializer());

            // Start the connection attempt.
            Channel ch = b.connect(host, port).sync().channel();
            // Read commands from the stdin.
            ChannelFuture lastWriteFuture = null;
            for (;;) {
                // Sends the received line to the server.
            	/**
            	 * 每分钟向Server发送一条心跳消息
            	 */
                //lastWriteFuture = ch.writeAndFlush("{\"feed_id\":10000,\"data\":\"817c0784cfea199ad35824efea8a40a681986e6312e3723849c8d538977a456efa299d7fb771f5c64e932773b8e12bd30b66ca2b2ab0ee6da8f96a24c9eba50e259f308a9d6b8776c4b4486e7dc597c3091268b4b9e6492b9137e17ae042a13c5b10cba863bc026d5705e1710b0fc76c928d3a3ce7b5ff2806c310999b9679970cab0213a99d96a2c7519cb6ad0c0a1bf270a29d9667ee52439ec4c52991ceda143273ec73bba341f2d7a55c2af07ad7678322f609f2d9cc3bf20ee89ce6a717b5d4d227824d7fd1921ab7c82d526ec9053a861a408e554d18e7c386aadae7ce2e14c0aa1c0f166d536c2d6199b07d8917556d06660853e32d462d38ea1a6cd40254a4285f38004831eb73ab94eabe05c8bfa87ebdada9ceeebdaae2bddac61784da7839ca9b3819debce2a3c8c05c2599b4c3d5683bd4e72be680b9114baa462018e404f9fc68611c5ab7e4c570478f43dc82016058bc1cbe66de2192cc1f57\"}" + "\r\n");

               // lastWriteFuture = ch.writeAndFlush("{\"feed_id\":10000,\"data\":\"867e489d353f21d025582103a76530f76ac8d24c33c5cb5642bb9094627b82ff4468072b8fa1f9aca1fcbb61a209d95f77f3fa4db2f115279d8d34e9771248722fe66ea2ae5829691d7ac67cd13c6795\"}" + "\r\n");
                JSONObject plainUpData = new JSONObject();
                Date now = new Date();
                String upData = "[{\"stream_id\":\"light\",\"datapoints\":[{\"value\":\"0\"},{\"at\":\"2014-12-04T13:45:43+0800\",\"value\":\"3\"}]}]";
                JSONArray upDataJson = JSONArray.parseArray(upData);
                String deviceStr = "{\"access_key\":\"6a97d3b4aec51a72944831ac9b4380b4\"}";
                JSONObject deviceJson = JSONObject.parseObject(deviceStr);
                plainUpData.put("code", 103);
                plainUpData.put("device", deviceJson);
                plainUpData.put("streams", upDataJson);
                plainUpData.put("timestamp",now.getTime()/1000);
                String cryptDataUpdata = AESUtils.encrypt(plainUpData.toJSONString(),"6a97d3b4aec51a72944831ac9b4380b4");
               
                JSONObject heart = new JSONObject();
                heart.put("code", 101);
                heart.put("device", deviceJson);
                
                heart.put("timestamp",now.getTime()/1000);
               // System.out.println(heart.toJSONString());
                String heartCryptData = AESUtils.encrypt(heart.toJSONString(),"6a97d3b4aec51a72944831ac9b4380b4");
                
                //System.out.println("enryp:"+heartCryptData);
                String heartDeptData = AESUtils.decrypt(heartCryptData, "6a97d3b4aec51a72944831ac9b4380b4");
               // System.out.println("decry:"+heartDeptData);
                
                JSONObject sendJson = new JSONObject();
                sendJson.put("feed_id", 10000);
                //sendJson.put("data", cryptDataUpdata);
                sendJson.put("data",heartCryptData);
               
                lastWriteFuture = ch.writeAndFlush(sendJson.toJSONString()+"\r\n");
                //System.out.println("send:"+sendJson.toJSONString());
                
                
                Thread.sleep(60*1000);
                // If user typed the 'bye' command, wait until the server closes
                // the connection.
                if ("bye".equals("")) {
                    ch.closeFuture().sync();
                    break;
                }
            }

            // Wait until all messages are flushed before closing the channel.
            if (lastWriteFuture != null) {
                lastWriteFuture.sync();
            }
        } finally {
            // The connection is closed automatically on shutdown.
            group.shutdownGracefully();
        }
    }
    
	public static void main(String[] args) throws Exception {
        //String host = "211.151.14.37";
        String host = "10.28.171.130";
        int port = 9301;

        new SecureAesDeviceClient(host, port).run();
    }
}
