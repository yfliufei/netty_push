/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.jd.smartcloud.test.client;

import java.net.URLDecoder;
import java.util.ArrayList;import java.util.HashMap;
import java.util.List;import java.util.Map;

import com.alibaba.fastjson.JSONArray;import org.apache.log4j.Logger;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * Handles a client-side channel.
 */
public class SecureDeviceClientHandler extends SimpleChannelInboundHandler<String> {

    private static final Logger logger = Logger.getLogger(
            SecureDeviceClientHandler.class.getName());

    @Override
    public void channelRead0(ChannelHandlerContext ctx, String msg) throws Exception {

    	String realMsg = URLDecoder.decode(msg, "UTF-8");
        logger.info(realMsg);
        JSONObject controllInfo = JSON.parseObject(realMsg);
        Integer code = controllInfo.getInteger("code");
        if(code == 1002){
        	String feedId = controllInfo.getString("feed_id");
        	ctx.writeAndFlush("{\"code\":102,\"result\":0,\"controll_resp\":{\"info\":\"Respone OK!\"},\"device\":{\"feed_id\":\""+feedId+"\"}}" + "\n");
        }
        if(code == 1004)
        {
            List list = JSONObject.parseObject("[\n" +
                    "  {\"stream_id\" : \"light\",\n" +
                    "    \"datapoints\":[\n" +
                    "    {\"at\":\"2013-04-22T00:35:43+0800\",\"value\":\"0\"},\n" +
                    "    {\"at\":\"2013-04-22T00:55:43+0800\",\"value\":\"0\"},\n" +
                    "    {\"at\":\"2013-04-22T01:15:43+0800\",\"value\":\"1\"},\n" +
                    "    {\"at\":\"2013-04-22T01:35:43+0800\",\"value\":\"1\"}\n" +
                    "  ]}\n" +
                    "  ]\n",ArrayList.class);
            String feedId = controllInfo.getString("feed_id");
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("code",104);
            jsonObject.put("result",0);
            jsonObject.put("streams",list);

            Map map = new HashMap();
            map.put("feed_id",feedId);
            jsonObject.put("device",map);
            ctx.writeAndFlush(jsonObject.toJSONString() + "\n");
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("Unexpected exception from downstream.", cause);
        ctx.close();
    }
    
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
    	super.channelActive(ctx);
    }
}
