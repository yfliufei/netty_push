package com.jd.smartcloud.test.client;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.domain.common.Message;

/**
 * Created with IntelliJ IDEA.
 * User: cdzhangzheng1
 * Date: 14-9-18
 * Time: 上午9:27
 * To change this template use File | Settings | File Templates.
 */
public class Test {

    public static void main(String[] args) {
        String str = "{\"feed_id\":10000,\"data\":{\n" +
                "\"code\":103,\"device\":{\"access_key\": \"6a97d3b4aec51a72944831ac9b4380b4\"},  \"streams\" : [\n" +
                "  {\"stream_id\" : \"light\",\n" +
                "    \"datapoints\":[\n" +
                "    {\"at\":\"2013-04-22T00:35:43+0800\",\"value\":\"0\"}\n" +
                "  ]}\n" +
                "  ]\n" +
                "}}\n" + "\r\n";

        System.out.println(str);
        JSONObject deviceResult = new JSONObject();
        JSONObject jsonObject = JSONObject.parseObject(str);
        JSONArray jsonArray = (JSONArray) jsonObject.get("streams");
        JSONArray dataPoints;
        JSONObject tmpObject;
        String stream_id;
        for (int i = 0; i < jsonArray.size(); i++) {
            tmpObject = jsonArray.getJSONObject(i);
            stream_id = tmpObject.getString("stream_id");
            dataPoints = tmpObject.getJSONArray("datapoints");
            if (null != dataPoints && dataPoints.size() > 0) {
                deviceResult.put(stream_id, dataPoints.getJSONObject(0));
            }
        }
        System.out.println(deviceResult.toJSONString());

    }
}
