/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.jd.smartcloud.test.client;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

/**
 * Simple SSL chat client modified from {@link TelnetClient}.
 */
public class SecureDeviceClient {

    private final String host;
    private final int port;
    
    public SecureDeviceClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public void run() throws Exception {
        EventLoopGroup group = new NioEventLoopGroup();
        try {
            Bootstrap b = new Bootstrap();
            b.group(group)
             .channel(NioSocketChannel.class)
             .handler(new SecureDeviceClientInitializer());

            // Start the connection attempt.
            Channel ch = b.connect(host, port).sync().channel();
            // Read commands from the stdin.
            ChannelFuture lastWriteFuture = null;
            for (;;) {
                // Sends the received line to the server.
            	/**
            	 * 每分钟向Server发送一条心跳消息
            	 */

                lastWriteFuture = ch.writeAndFlush("{\"code\": 103,\"device\": {\"feed_id\": \"10000\"},\"streams\": [{\"stream_id\": \"light\",\"datapoints\": [{\"at\": \"2013-04-22T00:35:43+0800\",\"value\": \"0\"},{\"at\": \"2013-04-22T00:35:43+0800\",\"value\": \"0\"}]}]}" + "\r\n");
                Thread.sleep(60*1000);
                // If user typed the 'bye' command, wait until the server closes
                // the connection.
                if ("bye".equals("")) {
                    ch.closeFuture().sync();
                    break;
                }
            }

            // Wait until all messages are flushed before closing the channel.
            if (lastWriteFuture != null) {
                lastWriteFuture.sync();
            }
        } finally {
            // The connection is closed automatically on shutdown.
            group.shutdownGracefully();
        }
    }
    
	public static void main(String[] args) throws Exception {
        //String host = "211.151.14.37";
        String host = "10.28.171.130";
        int port = 9101;

        new SecureDeviceClient(host, port).run();
    }
}
