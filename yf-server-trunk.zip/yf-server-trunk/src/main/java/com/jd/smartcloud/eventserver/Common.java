package com.jd.smartcloud.eventserver;

import com.jd.cachecloud.driver.jedis.ShardedXCommands;
import com.jd.smartcloud.common.RestApiCodes;
import com.jd.smartcloud.domain.common.Message;
import com.jd.smartcloud.safservice.DeviceSafService;
import io.netty.channel.SimpleChannelInboundHandler;
import org.apache.log4j.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: cdzhangzheng1
 * Date: 14-9-12
 * Time: 上午10:54
 * To change this template use File | Settings | File Templates.
 */
public abstract class Common extends SimpleChannelInboundHandler<String> {

    protected DeviceSafService deviceSafService;

    protected String getAccesskey(Long feedIdKey)
    {
        String cKey;
        Message message = deviceSafService.getAccesskey(feedIdKey);
        cKey = message.getData();
        if(null == cKey)
        {
            throw new IllegalArgumentException("param feed_id is error...");
        }
        return cKey;
    }
}
