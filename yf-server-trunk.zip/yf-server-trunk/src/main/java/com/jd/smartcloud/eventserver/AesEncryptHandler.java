package com.jd.smartcloud.eventserver;

import java.net.URLDecoder;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.service.Service;
import com.jd.smartcloud.constants.Constants;
import com.jd.smartcloud.util.AESUtils;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelOutboundHandlerAdapter;
import io.netty.channel.ChannelPromise;
import io.netty.util.ReferenceCountUtil;

public class AesEncryptHandler extends ChannelOutboundHandlerAdapter{
	private static final Logger logger = Logger.getLogger(AesEncryptHandler.class);
	
	@Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {		
		String msgStr = (String) msg;
		logger.info("rev:"+msgStr);
		if (null == msgStr) {
			logger.error("the msg is null when to cast to string in AesEncryptHandler");
			return;
		}
		msgStr = URLDecoder.decode(msgStr, "utf-8");
		JSONObject msgJson = null;
		try{
			msgJson = JSONObject.parseObject(msgStr);
		}catch(Exception e) {
			logger.error("exception occur when to change mgs to json in AesEncryptyHandler.msg:"+msgStr,e);
		}
		if (null == msgJson) {
			logger.error("the JsonObject cast from msg is null in AesEncryptHandler.msg:"+msgStr);
			return;
		}
		
		int code = msgJson.getIntValue("code");
		String feedId = msgJson.getString("feed_id");
		switch(code){
		case Constants.SERVER_CONTROLL:
			deviceControl(feedId,msgJson,ctx,msg,promise);
			break;
		case Constants.SERVER_GET_DEVICE_INFO:
			ctx.write(msg, promise);
			break;
		case Constants.DEVICE_HEARTBEAT_RESP:
			ctx.write(msg, promise);
			break;
		case Constants.SERVER_UP_DATA:
			ctx.write(msg, promise);
			break;
		case Constants.DEVICE_ERROR:
			ctx.write(msg, promise);
			break;
		case Constants.SERVER_EXCEPTION:
			ctx.write(msg, promise);
			break;
		default:
			logger.warn("code:"+code+" is new in AesEncryptHandler");
			ctx.write(msg, promise);
			break;
		}
	}
	
	@Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("exception occur in AesEncryptHandler",cause);
    }
	
	protected void deviceControl(String feedId,JSONObject msgJson,ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception{		
		String accesskey = Service.getAccesskeyFromDb(Long.valueOf(feedId));
		String data = AESUtils.encrypt(msgJson.getString("control"), accesskey);
		msgJson.put("control", data);
		ReferenceCountUtil.release(msg);
		ctx.write(msgJson.toJSONString() + Constants.RETURN_STRING, promise);
	}
}
