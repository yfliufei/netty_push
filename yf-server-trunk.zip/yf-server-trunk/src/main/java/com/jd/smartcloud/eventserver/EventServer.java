/*
 * Copyright 2012 The Netty Project
 *
 * The Netty Project licenses this file to you under the Apache License,
 * version 2.0 (the "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at:
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */
package com.jd.smartcloud.eventserver;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioServerSocketChannel;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.collections.map.LRUMap;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jd.smartcloud.common.SecurityLruMap;
import com.jd.smartcloud.constants.ConfigManager;
import com.jd.smartcloud.safservice.DeviceSafService;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * Simple SSL chat server modified from {@link TelnetServer}.
 */
public class EventServer {

	private static final int rest_port = Integer.parseInt(ConfigManager.getProp("rest.port"));
    private static final int device_port = Integer.parseInt(ConfigManager.getProp("device.port"));
    private static final int tcp_port = Integer.parseInt(ConfigManager.getProp("tcp.port"));
    private static final int aes_tcp_port = Integer.parseInt(ConfigManager.getProp("aes.tcp.port"));
    public static final int redis_expire = Integer.parseInt(ConfigManager.getProp("redis.expire"));
    private static String ip_prefix = ConfigManager.getProp("ip.prefix");
    private static final int replayAttWT = Integer.parseInt(ConfigManager.getProp("replyatt.timewindow"));
    public static final int session_expire=Integer.parseInt(ConfigManager.getProp("session.expired"));
    public static final int stun_session_expire=Integer.parseInt(ConfigManager.getProp("stun.session.expired"));
    public static final int stun_max_count=Integer.parseInt(ConfigManager.getProp("stun.max.count"));
    public static String localHost = null;
    private static final Logger logger = Logger.getLogger(EventServer.class);
    public static final ConcurrentMap<String, Channel> deviceChannelMap =  new ConcurrentHashMap<String, Channel>();
    public static final ConcurrentDevChaFeedId devChannelFeedIdMap = new ConcurrentDevChaFeedId();  
    public static final SecurityLruMap feedIdAccessKeyMap = new SecurityLruMap(100000);
    public static final SecurityLruMap deviceProduct = new SecurityLruMap(500000);
    public static final SecurityLruMap expendTime = new SecurityLruMap(500000);
    public static final AtomicInteger serialNum = new AtomicInteger((int)(Math.random()*100000));
    public static final ConcurrentMap<String, ConcurrentList > restChannelMap =  new ConcurrentHashMap<String, ConcurrentList>();
    public static ClassPathXmlApplicationContext applicationContext;
    public static class RestClient{
    	private Channel ch;
    	private long timestamp;// second
    	private int serial;
    	public RestClient(Channel ch,long timestamp,int serial){
    		this.ch = ch;
    		this.timestamp = timestamp;
    		this.serial = serial;
    	}
    	
    	public Channel getChannel(){
    			return this.ch;
    	}
    	
    	public long getTimestamp(){
    			return timestamp;
    	}
    	
    	public int getSerial(){
    			return serial;
    	}
    }
    
    public static class ConcurrentList{
    	private List<RestClient> list;
    	public ConcurrentList(){
    		list = new ArrayList<RestClient>();
    	}
    	public synchronized void addTail(RestClient t){
    		list.add(t);
    	}
    	
    	public synchronized RestClient poll(){
    		RestClient temp = list.remove(0);
    		while(temp != null){
    			Date now = new Date();
				if (now.getTime()/1000 - temp.getTimestamp() < 8) {
					break;
				}
				temp = list.remove(0);
    		}
    		return temp;
    	}
    	
    	public synchronized RestClient remove(int serial){
    		RestClient temp = null;
    		for (int i = 0; i < list.size(); i++) {
    			if (list.get(i).getSerial() == serial) {
    				temp = list.get(i);
    				list.remove(i);
    			}
    		}
    		return temp;
    	}
    }
    
    public static class ConcurrentDevChaFeedId{
    	private ConcurrentMap<Channel,ConcurrentSkipListSet<String> > container;
    	ConcurrentDevChaFeedId(){
    		container = new ConcurrentHashMap<Channel,ConcurrentSkipListSet<String> >();
    	}
    	
    	public  void add(Channel ch,String feedId){
    		if (null != ch) {
    			ConcurrentSkipListSet<String> feeds = container.get(ch);
    			if (null == feeds){
    				feeds = new ConcurrentSkipListSet<String>();
    			}
    			feeds.add(feedId);
    			container.put(ch, feeds);
    		}
    	}
    	
    	public  Set<String> remove(Channel ch){
    		ConcurrentSkipListSet<String> feeds = container.remove(ch);
    		if (null == feeds) {
    			feeds = new ConcurrentSkipListSet<String>();
    		}
    		return feeds;
    	}
    	
    	public  void erase(Channel ch,String feedId){
    		if (null != ch) {
    			ConcurrentSkipListSet<String> feeds = container.get(ch);
    			if (null != feeds){
    				feeds.remove(feedId);
    				if (feeds.isEmpty()) {
    					container.remove(ch);
    				}
    			}
    		}
    	}
    	
    	public Set<String> get(Channel ch){
    		ConcurrentSkipListSet<String> feeds = container.get(ch);
    		if (null == feeds) {
    			feeds = new ConcurrentSkipListSet<String>();
    		}
    		return feeds;
    	}
    }
    
    static {
    	final String instanceId=System.getProperty("instanceId");
    	// 系统存活监控
    	Profiler.InitHeartBeats("EventServer.server.process.instance"+instanceId+".heartbeat");
    	// JVM监控
    	Profiler.registerJVMInfo("EventServer.server.instance"+instanceId+".jvm");
    	try{
    		applicationContext=new ClassPathXmlApplicationContext(new String[] {"classpath:spring-config.xml"});
    		applicationContext.start();
    		//initialize saf service
    		DeviceSafService deviceSafService=(DeviceSafService) applicationContext.getBean("deviceSafService");
        	if(deviceSafService==null){
        		logger.error("Fatal Error, Initialize saf service fail...");
        		System.exit(0);
        	}
        	logger.info("initialize saf service success...");
        	
        	if (null == ip_prefix) {  
        		ip_prefix = "172";
        	}
        	
        	localHost = getLocalHost();
        	if (null == localHost){
        		logger.error("Fatal Error, the localHost is null");
        		System.exit(0);
        	} else {
        		logger.info("get localhost:"+localHost);
        	}
    	} catch(Exception e){
    		logger.error("Fatal Error, Initialize saf service fail...,errorMsg:"+e.getMessage(),e);
    		System.exit(0);
    	} 
    }
    
    
    public EventServer() {

    }


    /**
     * 启动所有服务，事件监听线程均采用1个，事件处理线程均采用默认个数（如为配置系统参数，默认为CPU核数的两倍）
     */
    public void start() {
        //启动REST API 服务
        startService(1,0,rest_port,new HttpRestInitializer());
        //启动SSL长连接服务
        startService(1,0,device_port,new HttpStreamingInitializer());
        //启动非SSL长连接服务
        startService(1,0,tcp_port,new HttpStreamingNSSLInitializer());
        //启动 AES 长连接服务
        startService(1,0,aes_tcp_port,new HttpStreamingAESInitializer());
    }

    /**
     * 启动NIO服务
     * @param bosst  事件监听线程数
     * @param workt  事件处理线程数
     * @param port   服务端口
     * @param ci     通道初始器
     */
    private void startService(final  int bosst, final  int workt,final int port,final ChannelInitializer ci){
        //监听设备端连接tcp
        new Thread(new Runnable() {
            @Override
            public void run() {
                EventLoopGroup bossGroup = new NioEventLoopGroup(bosst);
                EventLoopGroup workerGroup = new NioEventLoopGroup(workt);
                try {
                    ServerBootstrap b = new ServerBootstrap();
                    b.group(bossGroup, workerGroup)
                            .channel(NioServerSocketChannel.class)
                            .childHandler(ci);

                    b.bind(port).sync().channel().closeFuture().sync();
                    logger.info("Devices Listening is on... Port:" + port);
                } catch (InterruptedException e) {
                    logger.error("端口 " + port + " 的服务启动失败！",e);
                } finally {
                    bossGroup.shutdownGracefully();
                    workerGroup.shutdownGracefully();
                }
            }
        }).start();
    }

    public static String getLocalHost(){
    	Enumeration netInterfaces;
		try {
			netInterfaces = NetworkInterface.getNetworkInterfaces();
			InetAddress ip = null;   
			while(netInterfaces.hasMoreElements())   
			{   
			    NetworkInterface ni=(NetworkInterface)netInterfaces.nextElement();    
			    Enumeration<InetAddress> ips = ni.getInetAddresses();   
		        while (ips.hasMoreElements()) { 
		        	ip=ips.nextElement(); 
		        	
				    if (ip != null && ip instanceof Inet4Address) {
				    	String strIp = ip.getHostAddress();
				    	if (strIp.startsWith(ip_prefix)){
					    	 return strIp; 
				    	}	 
				    }    
		        }   		      
			}
		} catch (SocketException e) {
			logger.error("Fatal Error, to get local host fail...,errorMsg:"+e.getMessage(),e);
			System.exit(0);
		}		
		return null;
    }
    
    public static int getRestPort(){
    	return rest_port;
    }
    
    public static int getReplayAttWT(){
    	return replayAttWT;
    }
    
    public static void main(String[] args) throws Exception {
        new EventServer().start();
    }
}
