/*
 * Copyright 1998-2012 360buy.com All right reserved. This software is the
 * confidential and proprietary information of 360buy.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with 360buy.com.
 */
package com.jd.smartcloud.common;

/**
 * 类ResponseUtil.java的实现描述：TODO 类实现描述
 * RESTAPI状态码定义
 *
 * @author qingting 2014-3-19 下午4:18:33
 */
public class RestApiCodes {
    public static final int SUCCESS = 200;
    public static final String SUCCESS_MSG = "ok";

    //权限或参数验证相关
    public static final int UNAUTHORIZED = 1001;
    public static final String UNAUTHORIZED_MSG = "无权限或未授权";

    public static final int ILLEGAL_PARAM = 1002;
    public static final String ILLEGAL_PARAM_MSG = "传入参数非法";

    //数据相关
    public static final int NOT_FOUND_DATA = 2001;
    public static final String NOT_FOUND_DATA_MSG = "未找到数据";
    public static final int NOT_FOUND_PRODUCT_DATA = 2002;
    public static final String NOT_FOUND_PRODUCT_DATA_MSG = "未找到产品数据";
    public static final int NOT_FOUND_DEVICE_DATA = 2003;
    public static final String NOT_FOUND_DEVICE_DATA_MSG = "未找到设备数据";

    public static final int DEVICE_STATUS_OFFLINE = 2004;
    public static final String DEVICE_STATUS_OFFLINE_MSG = "设备不在线";

    public static final int SERVICE_UNAVAILABLE_BINDDEVICE_EXIST = 2005;
    public static final String SERVICE_UNAVAILABLE_BINDDEVICE_EXIST_MSG = "设备已绑定";

    //服务相关
    public static final int SERVICE_UNAVAILABLE = 3001;
    public static final String SERVICE_UNAVAILABLE_MSG = "服务不可用";

    public static final int SERVICE_UNAVAILABLE_PRODUCT_PUBLISHED = 3002;
    public static final String SERVICE_UNAVAILABLE_PRODUCT_PUBLISHED_MSG = "产品已发布,不更新";

    public static final int SERVICE_UNAVAILABLE_PRODUCT_EXIST = 3003;
    public static final String SERVICE_UNAVAILABLE_PRODUCT_EXIST_MSG = "产品名称已存在";


    //服务器内部错误
    public static final int INTERNAL_SERVER_ERROR = 5001;
    public static final String INTERNAL_SERVER_ERROR_MSG = "服务器错误或异常";


    public static final String AES_REDIS_PIX = "aes_";
}
