package com.jd.smartcloud.constants;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.jd.smartcloud.eventserver.EventServer;


public class ConfigManager {
	private static final Logger logger = Logger.getLogger(ConfigManager.class); 
	public static final Properties prop = new Properties();
	private static String rootPath;
	
	static {
    	File jarPath = new File(EventServer.class.getProtectionDomain().getCodeSource().getLocation().getFile());
    	rootPath = jarPath.getParentFile().getParent();
        try {
        	String instanceId=System.getProperty("instanceId");
        	logger.debug("instanceId:"+instanceId);
        	File propertiesFile = new File(rootPath+"/server"+instanceId+"/config/config"+instanceId+".properties");
        	if(propertiesFile.exists()){
        		prop.load(new FileInputStream(propertiesFile));
        		logger.debug("From Configue File："+propertiesFile.getPath());
        	}else{
        		prop.load(ClassLoader.getSystemClassLoader().getResourceAsStream("config"+instanceId+".properties"));
        		logger.debug("From Jar Resource："+ClassLoader.getSystemClassLoader().getResource("config"+instanceId+".properties"));
        	}
        } catch (FileNotFoundException e) {
            logger.error("读取配置文件失败，找不到文件！",e);
        } catch (IOException e) {
            logger.error("读取配置文件失败",e);
        }
    }
	 
	public static String getProp(String key){
		return prop.getProperty(key, null);
	}
	
	public static String getKeyStoreFilePath(){
		return rootPath+"/config/EventServerKeyStore";
	}
}
