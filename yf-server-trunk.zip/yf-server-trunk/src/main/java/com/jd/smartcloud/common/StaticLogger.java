package com.jd.smartcloud.common;

import org.apache.log4j.Logger;

public class StaticLogger {
	private static final Logger logger = Logger.getLogger(StaticLogger.class);
	public static void logInfo(String msg){
		logger.info(msg);
	}
}
