package com.jd.smartcloud.service;

import io.netty.channel.Channel;

import java.util.Set;

import org.apache.log4j.Logger;

import com.jd.cachecloud.driver.jedis.ShardedXCommands;
import com.jd.smartcloud.domain.common.Message;
import com.jd.smartcloud.eventserver.AesDecryptHandler;
import com.jd.smartcloud.eventserver.EventServer;
import com.jd.smartcloud.safservice.DeviceSafService;

public class Service {
	protected static final DeviceSafService deviceSafService = (DeviceSafService) EventServer.applicationContext.getBean("deviceSafService");
	protected static final ShardedXCommands redisClient = (ShardedXCommands) EventServer.applicationContext.getBean("redisClient");;
	private static final Logger logger = Logger.getLogger(AesDecryptHandler.class);
	
	public static String getAccesskey(Long feedId){
		String cKey = null;
		
		cKey = (String)EventServer.feedIdAccessKeyMap.get(feedId.toString());
		
		if (null == cKey) {
			Message message = deviceSafService.getAccesskey(feedId);
	        cKey = message.getData();
	        if (null != cKey) {
	        	EventServer.feedIdAccessKeyMap.put(feedId.toString(), cKey);
	        }
		}
		
		if (null == cKey) {
			logger.error("this accessKey of feedId "+feedId+" is null");
		}
        return cKey;
	}
	
	public static String getAccesskeyFromDb(Long feedId){
		String cKey = null;
		Message message = deviceSafService.getAccesskey(feedId);
        cKey = message.getData();
        return cKey;
	}
	
	public static void setLocalAccessKey(Long feedId,String accessKey){
		EventServer.feedIdAccessKeyMap.put(feedId.toString(), accessKey);
	}
	
	public static boolean isValidConn(Channel ch) {
        Set<String> feeds = EventServer.devChannelFeedIdMap.get(ch);
        for (String feed : feeds) {
            if (null != redisClient.get(feed)) {
                return true;
            }
        }
        return false;
    }
	
	public static boolean hasOtherDevConn(Channel ch,String feedId){
    	Set<String> feeds = EventServer.devChannelFeedIdMap.get(ch);
        for (String feed : feeds) {
        	if (feed.equals(feedId)) {
        		continue;
        	}
            if (null != redisClient.get(feed)) {
                return true;
            }
        }
        return false;
    }
	
	public static boolean singleConn(Channel ch,Long feedId){
		if (null != feedId) {
			return hasOtherDevConn(ch,feedId.toString());
		} else {
			return isValidConn(ch);
		}
	}
}
