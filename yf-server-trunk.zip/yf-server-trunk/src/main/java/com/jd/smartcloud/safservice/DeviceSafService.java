package com.jd.smartcloud.safservice;

import com.jd.smartcloud.domain.common.Message;

public interface DeviceSafService {
	public Message bindDevice(String deviceId,Long productId,String deviceName,String pin);
	public Message renameDevice(String deviceName,Long feedId,String pin);
	public Message getStreams(String pin,Long feed_id);
	public Message listUserDevices(String pin);
    public Message getAccesskey(long feedId);
	public Message unbindDevices(String pin,long feedId);
	public Message identifyFeed(Long feedId,String accessKey);

    /**
     *设备上传数据
     *@param feedId
     *@param jsonBody
     *
     */
    public Message saveStreams(Long feedId,String jsonBody);
   /**
    * 查询固件升级信息
    * @param feedId
    * @param version
    * @return
    */
   public Message checkFirmwareUpgradeInfo(Long feedId, Integer version);
   /**
    * 上报固件升级状态
    * @param feedId
    * @param version
    * @param status
    * @return
    */
   public Message upgradeStatus(Long feedId, Integer version, Integer status);
}
