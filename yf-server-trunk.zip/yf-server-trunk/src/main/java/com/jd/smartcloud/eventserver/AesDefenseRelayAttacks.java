package com.jd.smartcloud.eventserver;

import java.util.Date;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.constants.Constants;
import com.jd.smartcloud.service.Service;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

public class AesDefenseRelayAttacks extends SimpleChannelInboundHandler<String>{

	private static final Logger logger = Logger.getLogger(AesDefenseRelayAttacks.class);
	
	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg)
			throws Exception {
		// TODO Auto-generated method stub
		try {
			Date now = new Date();
			JSONObject msgJson = JSONObject.parseObject(msg);
			String feedId = msgJson.getJSONObject("device").getString("feed_id");
			Long timestamp = msgJson.getLong("timestamp");
			if (null != timestamp) {
				if (Math.abs(now.getTime()/1000 - timestamp) > EventServer.getReplayAttWT()) {
					logger.warn("the timestamp is out of data.msg:"+msg);
					writeError(Constants.DEVICE_ERROR,Constants.OUT_OF_DATE,"the timestamp is out of date",ctx,feedId);
				} else {
					ctx.fireChannelRead(msg);
				}
			} else {
				logger.warn("there is no timestamp.msg:"+msg);
				writeError(Constants.DEVICE_ERROR,Constants.NO_TIMESTAMP,"there is no timestamp",ctx,feedId);
			}			
		}catch(Exception e) {
			writeError(Constants.SERVER_EXCEPTION,Constants.SERVER_ERROR,"server error",ctx,"0");
			logger.error("exception occur in AesDefenseRelayAttacks.msg:"+msg,e);
		}
	}
	
	protected void writeError(int code,int result,String errorMsg,ChannelHandlerContext ctx,String feedId){
		Date now = new Date();
		JSONObject errorRet = new JSONObject();
		errorRet.put("code", code);
		errorRet.put("result", result);
		errorRet.put("errorMsg", errorMsg);
		errorRet.put("timestamp", now.getTime()/1000);
		boolean closeConn = false;
		if (feedId.equals("0")) {
			if (!Service.isValidConn(ctx.channel())) {
				closeConn = true;
			}
		} else {
			if (!Service.hasOtherDevConn(ctx.channel(),feedId)) {
				closeConn = true;
			}
		}
		if (closeConn) {			
			ctx.writeAndFlush(errorRet.toJSONString() + Constants.RETURN_STRING).addListener(ChannelFutureListener.CLOSE);
			logger.error("invalid connection and close connection");
		} else {
			ctx.writeAndFlush(errorRet.toJSONString() + Constants.RETURN_STRING);
		}		
	}
	
	@Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("exception occur in AesDefenseRelayAttacks",cause);
    }
}
