package com.jd.smartcloud.common;

import org.apache.commons.collections.map.LRUMap;

public class SecurityLruMap extends LRUMap {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SecurityLruMap(int i) {
		super(i);
	}

	@Override
	public synchronized Object put(Object key, Object value) {
		return super.put(key, value);
	}
	
	@Override
	public synchronized Object remove(Object key){
		return super.remove(key);
	}
	
	@Override
	public synchronized Object get(Object key) {
		return super.get(key);
	}
}
