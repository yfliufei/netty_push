package com.jd.smartcloud.eventserver;

import com.jd.cachecloud.driver.jedis.ShardedXCommands;
import com.jd.service.common.utils.StringUtils;
import com.jd.smartcloud.safservice.DeviceSafService;
import com.jd.smartcloud.util.AESUtils;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import java.util.Date;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.constants.Constants;
import com.jd.smartcloud.eventserver.EventServer.ConcurrentList;
import com.jd.smartcloud.eventserver.EventServer.RestClient;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public class HttpRestHandler extends Common {
    private static final Logger logger = Logger.getLogger(HttpRestHandler.class);
    protected ShardedXCommands redisClient;
    public HttpRestHandler() {
        deviceSafService = (DeviceSafService) EventServer.applicationContext.getBean("deviceSafService");
        redisClient = (ShardedXCommands) EventServer.applicationContext.getBean("redisClient");
    }

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, String msg)
            throws Exception {
        JSONObject msgJSON = null;
        logger.info("rev msg:"+msg);
        try {
            msgJSON = JSON.parseObject(msg);   
            if (!msgJSON.containsKey("code")) throw new IllegalArgumentException("param[code] is missing...");
            if (!msgJSON.containsKey("feed_id")) throw new IllegalArgumentException("param[feed_id] is missing...");

            Integer code = msgJSON.getInteger("code");
            final String feedId = msgJSON.getString("feed_id");
            //EventServer.restChannelMap.put(feedId, ctx.channel());
            Channel ch = EventServer.deviceChannelMap.get(feedId);

            switch (code) {
                case Constants.REST_CONTROLL:
                    CallerInfo info = Profiler.registerInfo("EventServer.handle.HttpRestHandler.REST_CONTROLL", false, true);
                    try {
                        if (ch == null) {
                            String errorMsg = "{\"code\":" + Constants.DEVICE_CONTROLL_RESP + ",\"result\":-3,\"control_resp\":{}}";
                            ctx.writeAndFlush(errorMsg).addListener(ChannelFutureListener.CLOSE);
                            return;
                        }

                        int serial = EventServer.serialNum.getAndIncrement();
                        /*	String key = EventServer.createRestChKey(feedId,String.valueOf(serial));
                                  EventServer.restChannelMap.put(key,ctx.channel());
                              */
                        ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
                        if (null == restClientList) {
                            synchronized (this) {
                                restClientList = EventServer.restChannelMap.get(feedId);
                                if (null == restClientList) {
                                    restClientList = new ConcurrentList();
                                    EventServer.restChannelMap.put(feedId, restClientList);
                                }
                            }
                        }
                        restClientList.addTail(new RestClient(ctx.channel(), (new Date()).getTime() / 1000, serial));

                        String controllInfo = msgJSON.getString("cmd");

                        JSONObject attObject = new JSONObject();
                        attObject.put("serial", serial);

                        Date sendTime = new Date();
                        ch.writeAndFlush("{\"code\":" + Constants.SERVER_CONTROLL
							+ ",\"control\":" + controllInfo + ",\"feed_id\":"
							+ feedId + ",\"attribute\":"
							+ attObject.toJSONString() + "}"
							+ Constants.RETURN_STRING);
                     
                        Date sendTimeAfter = new Date();
						logger.info("send control timestamp:"+ sendTime.getTime()+" sendAfter:"+sendTimeAfter.getTime()+" feedId:"+feedId+" serial:"+serial);
						
                        String expendTimeKey = Constants.SERVER_CONTROLL+"#"+feedId+"#"+serial;                        
                        EventServer.expendTime.put(expendTimeKey, sendTime.getTime());

                        break;
                    } catch (Exception ex) {
                        Profiler.functionError(info);
                        logger.error("处理设备控制失败:  " + msg, ex);
                        break;
                    } finally {
                        Profiler.registerInfoEnd(info);
                    }

                case Constants.REST_GET_DEVICE_INFO:
                    CallerInfo info1 = Profiler.registerInfo("EventServer.handle.HttpRestHandler.REST_GET_DEVICE_INFO", false, true);
                    try {
                        if (ch == null) {
                            String errorMsg = "{\"code\":" + Constants.GET_DEVICE_INFO + ",\"result\":-3,\"control_resp\":{}}";
                            ctx.writeAndFlush(errorMsg).addListener(ChannelFutureListener.CLOSE);
                            return;
                        }

                        int serial = EventServer.serialNum.getAndIncrement();
                        /*	String key = EventServer.createRestChKey(feedId,String.valueOf(serial));
                                  EventServer.restChannelMap.put(key,ctx.channel());
                              */
                        ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
                        if (null == restClientList) {
                            synchronized (this) {
                                restClientList = EventServer.restChannelMap.get(feedId);
                                if (null == restClientList) {
                                    restClientList = new ConcurrentList();
                                    EventServer.restChannelMap.put(feedId, restClientList);
                                }
                            }
                        }
                        restClientList.addTail(new RestClient(ctx.channel(), (new Date()).getTime() / 1000, serial));
                        JSONObject attObject = new JSONObject();
                        attObject.put("serial", serial);
                       
                        ch.writeAndFlush("{\"code\":" + Constants.SERVER_GET_DEVICE_INFO + ",\"feed_id\":" + feedId + ",\"attribute\":" + attObject.toJSONString() + "}" + Constants.RETURN_STRING);
                        
                        Date sendTime = new Date();
                        String expendTimeKey = Constants.SERVER_GET_DEVICE_INFO+"#"+feedId+"#"+serial;                        
                        EventServer.expendTime.put(expendTimeKey, sendTime.getTime());
                        break;
                    } catch (Exception ex) {
                        Profiler.functionError(info1);
                        logger.error("获取设备快照失败:  " + msg, ex);
                        break;
                    } finally {
                        Profiler.registerInfoEnd(info1);
                    }

                case Constants.REST_CHECK_STATUS:
                    CallerInfo info2 = Profiler.registerInfo("EventServer.handle.HttpRestHandler.REST_CHECK_STATUS", false, true);
                    try {
                        logger.error("Error:eventserver check status is called");
                        int flag = 1;
                        if (ch == null) {
                            flag = 0;
                        } else if (!ch.isActive()){
                          flag = 0;
                        }

                        String status = "{\"device_status\":{\"online\":" + flag + "},\"feed_id\":" + feedId + "}";
                        ctx.writeAndFlush(status + Constants.RETURN_STRING).addListener(new ChannelFutureListener() {

                            @Override
                            public void operationComplete(ChannelFuture future) throws Exception {
                                //EventServer.restChannelMap.remove(feedId);

                                if (future.isDone()) {
                                    future.channel().close();
                                }
                            }
                        });
                        break;
                    } catch (Exception ex) {
                        Profiler.functionError(info2);
                        logger.error("检查设备存活状态失败:  " + msg, ex);
                        break;
                    } finally {
                        Profiler.registerInfoEnd(info2);
                    }
                case Constants.REST_UPGRADE_CONTROLL:
                	CallerInfo info3 = Profiler.registerInfo("EventServer.handle.HttpRestHandler.REST_UPGRADE_CONTROLL", false, true);
                    logger.info("eventserver rest upgrade controll  is called");
                    try {
                        if (ch == null) {
                            String errorMsg = "{\"code\":" + Constants.UPGRADE_FIRMWARE_RESP + ",\"result\":-3,\"control_resp\":{}}";
                            ctx.writeAndFlush(errorMsg).addListener(ChannelFutureListener.CLOSE);
                            return;
                        }

                        int serial = EventServer.serialNum.getAndIncrement();
                        ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
                        if (null == restClientList) {
                            synchronized (this) {
                                restClientList = EventServer.restChannelMap.get(feedId);
                                if (null == restClientList) {
                                    restClientList = new ConcurrentList();
                                    EventServer.restChannelMap.put(feedId, restClientList);
                                }
                            }
                        }
                        restClientList.addTail(new RestClient(ctx.channel(), (new Date()).getTime() / 1000, serial));
                        JSONObject sendObj = new JSONObject();
                        JSONObject upgradeInfo = new JSONObject();
                        upgradeInfo.put("feed_id", feedId);
                        upgradeInfo.put("firm_version", msgJSON.getIntValue("firm_version"));
                        upgradeInfo.put("firm_url", msgJSON.getString("firm_url"));
                        sendObj.put("code", 1005);
                        sendObj.put("update", upgradeInfo);
                        sendObj.put("serial", serial);
                        StringBuffer sb = new StringBuffer();
    					sb.append(System.currentTimeMillis()).append("-")
    							.append(feedId).append("-").append(msgJSON.getIntValue("firm_version"));
    					sendObj.put("session_id", sb.toString());
    					redisClient.set(sb.toString(), "0");
    					redisClient.expire(sb.toString(), EventServer.session_expire);
                        long start=System.currentTimeMillis();
                        ch.writeAndFlush(sendObj.toJSONString()+ Constants.RETURN_STRING);
						logger.info("send upgrade info:"+sendObj.toJSONString()+" cost:"+ (start-System.currentTimeMillis())+" ms, feedId:"+feedId+" serial:"+serial);
                        break;
                    } catch (Exception ex) {
                        Profiler.functionError(info3);
                        logger.error("upgrade command fail:  " + msg, ex);
                        break;
                    } finally {
                        Profiler.registerInfoEnd(info3);
                    }
                case Constants.DISPATCHER_STUN_SERVER:
                	CallerInfo info4 = Profiler.registerInfo("EventServer.handle.HttpRestHandler.DISPATCHER_STUN_SERVER", false, true);
                    logger.info("eventserver rest dispather stun server  is called");
                    try {
                        if (ch == null) {
                            String errorMsg = "{\"code\":" + Constants.STUN_SERVER_DISPTCHER_RESP + ",\"result\":-3,\"control_resp\":{}}";
                            ctx.writeAndFlush(errorMsg).addListener(ChannelFutureListener.CLOSE);
                            return;
                        }

                        int serial = EventServer.serialNum.getAndIncrement();
                        ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
                        if (null == restClientList) {
                            synchronized (this) {
                                restClientList = EventServer.restChannelMap.get(feedId);
                                if (null == restClientList) {
                                    restClientList = new ConcurrentList();
                                    EventServer.restChannelMap.put(feedId, restClientList);
                                }
                            }
                        }
                        restClientList.addTail(new RestClient(ctx.channel(), (new Date()).getTime() / 1000, serial));
                        JSONObject sendObj = new JSONObject();
                        JSONObject stunServerInfo = new JSONObject();
                        stunServerInfo.put("stun_ip", msgJSON.getString("stunIp"));
                        stunServerInfo.put("stun_port", msgJSON.getIntValue("stunPort"));
                        stunServerInfo.put("session_id", msgJSON.getString("sessionId"));
                        sendObj.put("code", Constants.STUN_SERVER_DISPTCHER);
                        sendObj.put("stun_info", stunServerInfo);
                        sendObj.put("serial", serial);
                        long start=System.currentTimeMillis();
                        ch.writeAndFlush(sendObj.toJSONString()+ Constants.RETURN_STRING);
						logger.info("send stun server info:"+sendObj.toJSONString()+" cost:"+ (start-System.currentTimeMillis())+" ms, feedId:"+feedId+" serial:"+serial);
                        break;
                    } catch (Exception ex) {
                        Profiler.functionError(info4);
                        logger.error("dispather stun server command fail:  " + msg, ex);
                        break;
                    } finally {
                        Profiler.registerInfoEnd(info4);
                    }
                case Constants.REST_VIDEO_CONTROLL:
                	CallerInfo info5 = Profiler.registerInfo("EventServer.handle.HttpRestHandler.REST_VIDEO_CONTROLL", false, true);
                    logger.info("eventserver rest video controll  is called");
                    try {
                        if (ch == null) {
                            String errorMsg = "{\"code\":" + Constants.VIDEO_CONTORL_RESP + ",\"result\":-3,\"control_resp\":{}}";
                            ctx.writeAndFlush(errorMsg).addListener(ChannelFutureListener.CLOSE);
                            return;
                        }

                        int serial = EventServer.serialNum.getAndIncrement();
                        ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
                        if (null == restClientList) {
                            synchronized (this) {
                                restClientList = EventServer.restChannelMap.get(feedId);
                                if (null == restClientList) {
                                    restClientList = new ConcurrentList();
                                    EventServer.restChannelMap.put(feedId, restClientList);
                                }
                            }
                        }
                        restClientList.addTail(new RestClient(ctx.channel(), (new Date()).getTime() / 1000, serial));
                        JSONObject sendObj = new JSONObject();
                        sendObj.put("ctl_type", msgJSON.getIntValue("ctr_type"));
                        sendObj.put("code", Constants.VIDEO_CONTORL);
                        sendObj.put("serial", serial);
                        long start=System.currentTimeMillis();
                        ch.writeAndFlush(sendObj.toJSONString()+ Constants.RETURN_STRING);
						logger.info("send video control :"+sendObj.toJSONString()+" cost:"+ (start-System.currentTimeMillis())+" ms, feedId:"+feedId+" serial:"+serial);
                        break;
                    } catch (Exception ex) {
                        Profiler.functionError(info5);
                        logger.error("ideo control  command fail:  " + msg, ex);
                        break;
                    } finally {
                        Profiler.registerInfoEnd(info5);
                    }
                default:
                    break;
            }
        } catch (Exception e) {
            ctx.writeAndFlush("{\"code\":" + Constants.DEVICE_CONTROLL_RESP
                    + ",\"result\":" + Constants.SERVER_ERROR
                    + ",\"errorMsg\":" + "server error"
                    + "}" + Constants.RETURN_STRING).addListener(ChannelFutureListener.CLOSE);
            logger.error("ERROR ocurred: " + e.getMessage(), e);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause)
            throws Exception {
        logger.error("Unexpected exception from downstream.", cause);
        ctx.close();
    }

    public DeviceSafService getDeviceSafService() {
        return deviceSafService;
    }

    public void setDeviceSafService(DeviceSafService deviceSafService) {
        this.deviceSafService = deviceSafService;
    }

}
