package com.jd.smartcloud.util;

/**
 * Created with IntelliJ IDEA.
 * User: cdzhangzheng1
 * Date: 14-9-11
 * Time: 下午4:40
 * To change this template use File | Settings | File Templates.
 */

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AESUtils {

    private static Cipher cipher;

    public static void main(String[] args) throws Exception {

        /*
        加密用的Key
        可以用26个字母和数字组成，最好不要用保留字符，虽然不会错，至于怎么裁决，个人看情况而定
        */

        String cKey = "0d8cc9708fbb662249e37757f4a24401";
        //需要加密的字串
        String cSrc = "我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621我的MSN：miaozu@msn.com，QQ：68524621";
        //加密
        long lStart = System.currentTimeMillis();
        String enString = AESUtils.encrypt(cSrc, cKey);
        System.out.println("加密后的字串是：" + enString);
        long lUseTime = System.currentTimeMillis() - lStart;
        System.out.println("加密耗时：" + lUseTime + "毫秒");
        //解密
        lStart = System.currentTimeMillis();
        String DeString = "";
        try {
            System.out.println("sdf");
            DeString = AESUtils.decrypt(enString, "0d8cc9708fbb662249e37757f4a24405");
        } catch (Exception e) {
            System.out.println("sdfdsf");
            DeString = AESUtils.decrypt(enString, cKey);
        }
        System.out.println("解密后的字串是：" + DeString);
        lUseTime = System.currentTimeMillis() - lStart;
        System.out.println("解密耗时：" + lUseTime + "毫秒");
    }

    public static String decrypt(String sSrc, String sKey) throws Exception {
        try {

            //判断Key是否正确
            if (sKey == null) {
                System.out.print("Key为空null");
                return null;
            }
            byte[] raw = sKey.getBytes("ASCII");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            if (null == cipher) {
                cipher = Cipher.getInstance("AES");
            }
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            byte[] encrypted1 = hex2byte(sSrc);
            try {
                byte[] original = cipher.doFinal(encrypted1);
                String originalString = new String(original);
                return originalString;
            } catch (Exception e) {
                System.out.println(e.toString());
                return null;
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());
            return null;
        }
    }

    //判断Key是否正确
    public static String encrypt(String sSrc, String sKey) throws Exception {
        if (sKey == null) {
            System.out.print("Key为空null");
            return null;
        }

        byte[] raw = sKey.getBytes("ASCII");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        if (null == cipher) {
            cipher = Cipher.getInstance("AES");
        }
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
        byte[] encrypted = cipher.doFinal(sSrc.getBytes());
        return byte2hex(encrypted).toLowerCase();
    }

    public static byte[] hex2byte(String strhex) {
        if (strhex == null) {
            return null;
        }
        int l = strhex.length();
        if (l % 2 == 1) {
            return null;
        }
        byte[] b = new byte[l / 2];
        for (int i = 0; i != l / 2; i++) {
            b[i] = (byte) Integer.parseInt(strhex.substring(i * 2, i * 2 + 2), 16);
        }
        return b;
    }

    public static String byte2hex(byte[] b) {
    	StringBuilder hsBuilder = new StringBuilder("");
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1) {
            	hsBuilder.append("0").append(stmp);
            } else {
            	hsBuilder.append(stmp);
            }
        }
        return hsBuilder.toString().toUpperCase();
    }

}