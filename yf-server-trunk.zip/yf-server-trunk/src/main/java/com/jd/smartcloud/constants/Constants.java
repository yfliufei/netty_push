package com.jd.smartcloud.constants;

/**
 * 普通常量类
 * @author liangxi
 *
 */
public class Constants {
	//换行符
	public static final String RETURN_STRING = "\n";
	//Http鉴别用头信息
	public static final String REST_SERVER = "rest-server";
	//返回给Device的时间格式
	public static final String DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
	//REST -> Server
	public static final int REST_CONTROLL = 0;
	public static final int REST_CHECK_STATUS = 1;
    public static final int REST_GET_DEVICE_INFO = 2;
    public static final int REST_UPGRADE_CONTROLL = 3;
    public static final int DISPATCHER_STUN_SERVER = 4;
    public static final int REST_VIDEO_CONTROLL = 5;
	//Device -> Server
	public static final int DEVICE_HEARTBEAT = 101;
	public static final int DEVICE_CONTROLL_RESP = 102;
    public static final int DEVICE_UP_DATA = 103;
    public static final int GET_DEVICE_INFO = 104;
    public static final int UPGRADE_FIRMWARE_RESP =105;
    public static final int CHECK_UPGRADE_FIRMWARE =106;
    public static final int UPGRADE_FIRMWARE_STATUS =107;
    public static final int STUN_SERVER_DISPTCHER_RESP=108;
    public static final int REPORT_STUN_INFO=109;
    public static final int REPORT_P2P_RESULT=110;
    public static final int VIDEO_CONTORL_RESP=111;
	//Server -> Device
	public static final int DEVICE_HEARTBEAT_RESP = 1001;
	public static final int SERVER_CONTROLL = 1002;
    public static final int SERVER_UP_DATA = 1003;
    public static final int SERVER_GET_DEVICE_INFO = 1004;
    public static final int SERVER_UPGRADE_FIRMWARE =1005;
    public static final int SERVER_CHECK_UPGRADE_FIRMWARE =1006;
    public static final int SERVER_UPGRADE_FIRMWARE_STATUS =1007;
    public static final int STUN_SERVER_DISPTCHER=1008;
    public static final int REPORT_STUN_INFO_RESP=1009;
    public static final int REPORT_P2P_RESULT_RESP=1010;
    public static final int VIDEO_CONTORL=1011;
    public static final int DEVICE_ERROR = 4000;
    public static final int SERVER_EXCEPTION = 5000;
	//Error Code
	public static final int SUCCESS = 0;
	public static final int AUTH_FAIL = -1;
	public static final int NOT_AUTH = -2;
	public static final int NOT_ACCESS = -3;
	public static final int NOT_SUPPORT = -4;
	public static final int SERVER_ERROR = -500;
	public static final int NO_MSG = -5;
	public static final int NOT_JSON = -6;
	public static final int NO_DATA = -7;
	public static final int MSG_NOT_COMPLETE = -8;
	public static final int AES_DECRYPT_ERROR = -9;
	public static final String SAF_SUCCESS="200";
	public static final int UP_DATA_FAIL = -10;
	public static final int NO_TIMESTAMP = -11;
	public static final int OUT_OF_DATE = -12;
    //厂商设备数据统计缓存中Key的前缀  数据结构：HSET
    public static final String CACHE_PREFIX_ONLINE_NUM_HEST = "SMART.DEVICE.ONLINE.NUM:HEST_";//设备当前在线数的前缀 HSET
    public static final String CACHE_PREFIX_FEEDID_PRODUCTID_MAP = "SMART.FEEDID_PRODUCTID:MAP_HSET";//Feed_id与product_id的映射表  HSET
    public static final String APP_STUN_PREFIX="A_STUN_";//app stun info prefix
    public static final String DEVICE_STUN_PREFIX="D_STUN_";//device stun info prefix
    //bizness error code
    public static final int PARAMMETER_ERROR=10000;
    public static final int INTERNAL_SERVER_ERROR=10001;
    public static final int PRODUCT_UPGRADE_FORBIDDEN=10005;
    public static final int APP_STUN_INFO_NOT_FOUND=10006;
}
