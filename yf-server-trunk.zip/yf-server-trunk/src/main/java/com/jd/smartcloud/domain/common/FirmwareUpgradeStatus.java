package com.jd.smartcloud.domain.common;

public enum FirmwareUpgradeStatus {
	DEFAULT,//0
	UPGRADING,//1
	SUCCESS,//2
	FAIL;//3
}
