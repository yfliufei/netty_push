/*
 * Copyright (c) 2014 www.jd.com All rights reserved.
 * 本软件源代码版权归京东成都云平台所有,未经许可不得任意复制与传播.
 */
package com.jd.smartcloud.domain.common;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.codehaus.jackson.annotate.JsonProperty;

import com.jd.smartcloud.common.RestApiCodes;

/**
 * 页面消息
 * @author J-ONE
 * @since 2014-03-18
 */
@SuppressWarnings("serial")
public class Message implements java.io.Serializable{
	private String code="200";// 编码
	//private String result;// 结果
	private Object data;// 数据
	
	@JsonProperty("error_msg") 
	private String errorMsg="ok";//结果
	
	public Message() {
		// 默认构造方法
	}

	public Message(String code, String errorMsg) {
		this.code = code;
		this.errorMsg = errorMsg;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

//	public String getResult() {
//		return result;
//	}
//
//	public void setResult(String result) {
//		this.result = result;
//	}
	
	@SuppressWarnings("unchecked")
	public <E> E getData() {
		return (E) data;
	}
	
	public void setData(Object data) {
		this.data = data;
	}
	
	public static Message create(String code,String result) {
		return new Message(code, result);
	}
	
	public static Message success() {
		return success("ok");
	}
	
	public static Message success(String msg) {
		return create("200", msg);
	}

	public static Message failure() {
		return failure("failure!");
	}
	
	public static Message failure(String msg) {
		return create(""+RestApiCodes.INTERNAL_SERVER_ERROR, msg);
	}
	
	public static Message failure(Exception ex) {
		return failure("exception:"+ex.getMessage(),ex);
	}
	
	public static Message failure(String message, Exception ex) {
		if(ex == null) {
			return failure();
		}
		Message msg = failure(message);
		try {
			StringWriter sw = new StringWriter();
			ex.printStackTrace(new PrintWriter(sw));
			msg.setData(sw.toString());
		} catch (Exception e) {
		}
		return msg;
	}

    public String getErrorMsg() {
        return errorMsg;
    }
    
    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
	
}
