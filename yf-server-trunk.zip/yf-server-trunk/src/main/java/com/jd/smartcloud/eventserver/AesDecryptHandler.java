package com.jd.smartcloud.eventserver;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.jd.smartcloud.service.Service;
import com.jd.smartcloud.constants.Constants;
import com.jd.smartcloud.util.AESUtils;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

public class AesDecryptHandler extends SimpleChannelInboundHandler<String>{
	private static final Logger logger = Logger.getLogger(AesDecryptHandler.class);
	
	@Override
	protected void channelRead0(ChannelHandlerContext ctx, String msg)
			throws Exception {
		// TODO Auto-generated method stub
		JSONObject msgJson = checkMsg(msg,ctx);
		logger.info("rev:"+msg);
		if (null != msgJson) {
			Long feedId = msgJson.getLong("feed_id");
			String accessKey = Service.getAccesskey(feedId);
			if (null != accessKey){
				String cryptDataStr = msgJson.getString("data");
				JSONObject plainDataJson = getPlainData(cryptDataStr,accessKey,feedId,ctx);
				if (null != plainDataJson) {
					JSONObject deviceJson = plainDataJson.getJSONObject("device");
					deviceJson.put("feed_id", feedId.toString());
					plainDataJson.put("device", deviceJson);
					ctx.fireChannelRead(plainDataJson.toJSONString());
				}				
			} else {
				logger.error("there is no accessKey of feedId:"+feedId);
				writeError(Constants.DEVICE_ERROR,Constants.AUTH_FAIL,"there is no this feed_id",ctx);
			}
		}		
	}
	
	protected void writeError(int code,int result,String errorMsg,ChannelHandlerContext ctx){
		if (!Service.isValidConn(ctx.channel())) {
			ctx.writeAndFlush("{\"code\":" + code
	                + ",\"result\":" + result
	                + ",\"errorMsg\":\"" + errorMsg
	                + "\"}" + Constants.RETURN_STRING).addListener(ChannelFutureListener.CLOSE);
			logger.error("invalid connection and close connection");
		} else {
			ctx.writeAndFlush("{\"code\":" + code
	                + ",\"result\":" + result
	                + ",\"errorMsg\":\"" + errorMsg
	                + "\"}" + Constants.RETURN_STRING);
		}		
	}
	
	protected JSONObject checkMsg(String msg,ChannelHandlerContext ctx){
		String msgStr = (String) msg;
		int errorCode = 0;
		String errorMsg = "";
		if (null == msgStr) {
			logger.error("the msg is null when to cast to string in AesEncryptHandler");
			errorCode = Constants.NO_MSG;
			errorMsg = "message is null";
			writeError(Constants.DEVICE_ERROR,errorCode,errorMsg,ctx);
			return null;
		}
		
		JSONObject msgJson = null;
		try {
			msgJson = JSONObject.parseObject(msgStr);
		}catch(Exception e){
			logger.error("exception occur when to cast msg to json in AesEncryptHandler.msg:"+msgStr);
		}
		
		if (null == msgJson) {
			logger.error("the JsonObject cast from msg is null in AesEncryptHandler.msg:"+msgStr);
			errorCode = Constants.NOT_JSON;
			errorMsg = "message is not json format";
			writeError(Constants.DEVICE_ERROR,errorCode,errorMsg,ctx);
			return null;
		}
		
		String data = msgJson.getString("data");
		String feedIdStr = msgJson.getString("feed_id");
		
		Long feedId = 0L;
		try {
			feedId = Long.valueOf(feedIdStr);
		} catch (NumberFormatException nume) {
			logger.error("feedId is not number in AesEncryptHandler.msg:"+msgStr,nume);
		} catch (Exception e){
			logger.error("exception occur in AesEncryptHandler",e);
		}
		
		if (null == data || 0 == feedId) {
			logger.error("there is no data or feedId in msg in AesEncryptHandler.msg:"+msgStr);
			errorCode = Constants.MSG_NOT_COMPLETE;
			errorMsg = "the format of msg is not right";
			writeError(Constants.DEVICE_ERROR,errorCode,errorMsg,ctx);
			return null;
		}		

		return msgJson;
	}
	
	protected JSONObject getPlainData(String cryptData,String secretKey,Long feedId,ChannelHandlerContext ctx) {
		JSONObject plainDataJson = null;
		try {
			String plainDataStr = AESUtils.decrypt(cryptData, secretKey);						
			if (null == plainDataStr) {
				String accessKeyFromDb = Service.getAccesskeyFromDb(feedId);
				if (!accessKeyFromDb.equals(secretKey)) {
					Service.setLocalAccessKey(feedId,accessKeyFromDb);
					plainDataStr = AESUtils.decrypt(cryptData, accessKeyFromDb);					
				}				
			}
			
			if (null != plainDataStr) {
				plainDataJson = JSONObject.parseObject(plainDataStr);
				if (null == plainDataJson || !plainDataJson.containsKey("device")) {
					logger.error("the plainDataJson is null or no device in msg in AesEncryptHandler.plainDataStr:"+plainDataStr);
					int errorCode = Constants.MSG_NOT_COMPLETE;
					String errorMsg = "there is no device part in encrypt data";
					writeError(Constants.DEVICE_ERROR,errorCode,errorMsg,ctx);
					return null;
				}
			} else {
				logger.error("the plainDataStr is null in msg in AesEncryptHandler");
				int errorCode = Constants.AES_DECRYPT_ERROR;
				String errorMsg = "decrypt error";
				writeError(Constants.DEVICE_ERROR,errorCode,errorMsg,ctx);
				return null;
			}
			return plainDataJson;			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("exception occur when decryption in AesEncryptHandler",e);
			return null;
		}
	}
	
	@Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("exception occur in AesDecryptHandler",cause);
    }
}
