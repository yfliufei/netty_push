package com.jd.smartcloud.eventserver;

import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;
import com.jd.cachecloud.driver.jedis.ShardedXCommands;
import com.jd.service.common.utils.StringUtils;
import com.jd.smartcloud.common.RestApiCodes;
import com.jd.smartcloud.common.StaticLogger;
import com.jd.smartcloud.constants.Constants;
import com.jd.smartcloud.domain.common.Message;
import com.jd.smartcloud.eventserver.EventServer.ConcurrentList;
import com.jd.smartcloud.eventserver.EventServer.RestClient;
import com.jd.smartcloud.safservice.DeviceSafService;
import com.jd.smartcloud.service.Service;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;


/**
 * Handles a server-side channel.
 */
public class HttpStreamingHandler extends SimpleChannelInboundHandler<String> {

    private static final Logger logger = Logger.getLogger(HttpStreamingHandler.class);
    protected DeviceSafService deviceSafService;
    protected ShardedXCommands redisClient;

    public HttpStreamingHandler() {
        deviceSafService = (DeviceSafService) EventServer.applicationContext.getBean("deviceSafService");
        redisClient = (ShardedXCommands) EventServer.applicationContext.getBean("redisClient");
        if (null == deviceSafService || redisClient == null) {
            logger.error("reference saf or redisClient service fail...");
            System.exit(0);
        }
    }

    @Override
    public void channelActive(final ChannelHandlerContext ctx) throws Exception {
        //logger.debug("Connected:" + ctx.channel().remoteAddress());
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) {
        Set<String> feeds = EventServer.devChannelFeedIdMap.remove(ctx.channel());
        logger.info("disconnected. Remote address: " + ctx.channel().remoteAddress() + ", feeds: " + feeds);
        for (String feed : feeds) {
        	redisClient.del(feed);
            EventServer.deviceChannelMap.remove(feed);
        }
    }

    @Override
    public void channelRead0(final ChannelHandlerContext ctx, String msg) throws Exception {
        JSONObject msgJSON = null;
        Integer code = null;
        Long feedIdL = null;
        String accessKey = null;
        try {
            logger.info("receiveMsg:" + msg);
            msgJSON = checkMsgFormat(msg);
            if (msgJSON == null) {
            	String errorResp = createErrorResp(Constants.DEVICE_ERROR,Constants.MSG_NOT_COMPLETE,"the info is neither complete nor json");
            	feedIdL = getFeedIdFromMsg(msg);
            	if (!Service.singleConn(ctx.channel(), feedIdL)) {
            		logger.error("there is no feedId or accesskey in msg or json and to close connection. " + "msg: "+msg + ". Remote address: " + ctx.channel().remoteAddress());
            		ctx.writeAndFlush(errorResp).addListener(ChannelFutureListener.CLOSE);
            	} else {
            		logger.error("there is no feedId or accesskey in msg or json but not to close connection. " + "msg: "+msg + ". Remote address: " + ctx.channel().remoteAddress());
            		ctx.writeAndFlush(errorResp);
            	} 
            	return;
            }

            code = msgJSON.getInteger("code");
            feedIdL = msgJSON.getJSONObject("device").getLong("feed_id");
            if (msgJSON.getJSONObject("device").containsKey("access_key")) {
                accessKey = msgJSON.getJSONObject("device").getString("access_key");
            } else {
                accessKey = msgJSON.getJSONObject("device").getString("accees_key");
                if (msgJSON.getJSONObject("device").containsKey("accees_key")) {
                	CallerInfo accessWrong = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.accesswrong", false, true);
                	Profiler.registerInfoEnd(accessWrong);
                	logger.warn("first version . accees_key in use .feedId:"+feedIdL);
                }
            }
           
            if (!authDevice(feedIdL.toString(),accessKey,ctx)){
            	return;
            }
            
            devInfoProcess(feedIdL.toString(),ctx);
            
            switch (code) {

                case Constants.DEVICE_HEARTBEAT:                    
                    logger.info("Receive Heartbeat from" + ctx.channel().remoteAddress() + " | " + "Feed_ID:" + feedIdL + Constants.RETURN_STRING);
                    // 减少在线日志
                    if (((long)(Math.random() * 20000))%2 == 1) {
                    	StaticLogger.logInfo("|||logType:isOnlineLog|||feedId:"+feedIdL);
                    }				
                    CallerInfo info = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.DEVICE_HEARTBEAT", false, true);
                    heartBeat(ctx, msg, msgJSON, feedIdL.toString(), info);
                    break;
                case Constants.DEVICE_CONTROLL_RESP:
                    CallerInfo info2 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.DEVICE_CONTROLL_RESP", false, true);
                    deviceControll(msg, msgJSON, feedIdL.toString(), info2);
                    break;
                case Constants.DEVICE_UP_DATA:
                    CallerInfo info3 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.DEVICE_UP_DATA", false, true);
                    deviceUpData(ctx, msg, msgJSON, feedIdL.toString(), info3);
                    break;
                case Constants.GET_DEVICE_INFO:
                    CallerInfo info4 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.GET_DEVICE_INFO", false, true);
                    deviceGetInfo(msg, msgJSON, feedIdL.toString(), info4);
                    break;
                case Constants.CHECK_UPGRADE_FIRMWARE:
    				CallerInfo info5 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.CHECK_UPGRADE_FIRMWARE",false, true);
    				checkUpgrade(ctx, msg, msgJSON, feedIdL.toString(), accessKey, info5);
    				break;
    			case Constants.UPGRADE_FIRMWARE_STATUS:
    				CallerInfo info6 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.UPGRADE_FIRMWARE_STATUS",false, true);
    				upgradeStatus(ctx, msg, msgJSON, feedIdL.toString(), accessKey, info6);
    				break;
    			case Constants.UPGRADE_FIRMWARE_RESP:
    				CallerInfo info7 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.UPGRADE_FIRMWARE_RESP",false, true);
    				commonResp(ctx, msg, msgJSON, feedIdL.toString(), accessKey, info7);
    				break;
    			case Constants.STUN_SERVER_DISPTCHER_RESP:
    				CallerInfo info8 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.STUN_SERVER_DISPTCHER_RESP",false, true);
    				commonResp(ctx, msg, msgJSON, feedIdL.toString(), accessKey, info8);
    				break;
    			case Constants.REPORT_STUN_INFO:
    				CallerInfo info9 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.REPORT_STUN_INFO",false, true);
    				reportStunInfo(ctx, msg, msgJSON, feedIdL.toString(), accessKey, info9);
    				break;
    			case Constants.REPORT_P2P_RESULT:
    				CallerInfo info10 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.REPORT_P2P_RESULT",false, true);
    				reportP2PResult(ctx, msg, msgJSON, feedIdL.toString(),  info10);
    				break;
    			case Constants.VIDEO_CONTORL_RESP:
    				CallerInfo info11 = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.VIDEO_CONTORL_RESP",false, true);
    				commonResp(ctx, msg, msgJSON, feedIdL.toString(), accessKey, info11);
    				break;
                default:
                    ctx.close();
                    break;
            }
        } catch (Exception e) {
            ctx.writeAndFlush("{\"code\":" + Constants.DEVICE_CONTROLL_RESP
                    + ",\"result\":" + Constants.SERVER_ERROR
                    + ",\"errorMsg\":" + "\"server error\""
                    + "}" + Constants.RETURN_STRING);
            logger.error("ERROR ocurred: " + e.getMessage(), e);
        }
    }

    protected void deviceUpData(ChannelHandlerContext ctx, String data, JSONObject msgJSON, String feedId, CallerInfo info3) {
        JSONObject resp = new JSONObject();
        resp.put("code", Constants.SERVER_UP_DATA);
        logger.info("Receive updata from" + ctx.channel().remoteAddress() + " | " + "Feed_ID:" + feedId + Constants.RETURN_STRING);
        try {
            logger.info(data);
            Message msg = deviceSafService.saveStreams(Long.valueOf(feedId), data);
            resp = new JSONObject();
            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_PATTERN);
            Date nowTime = new Date();
            resp.put("code", Constants.SERVER_UP_DATA);
            resp.put("time", formatter.format(nowTime));
            resp.put("timestamp", nowTime.getTime()/1000);
            if ("200".equals(msg.getCode())) {               
                resp.put("result", Constants.SUCCESS);
            } else {            	 
                resp.put("result",Constants.UP_DATA_FAIL);
                resp.put("errorMsg", msg.getErrorMsg());                
            }
            ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
            logger.info("Response updata to" + ctx.channel().remoteAddress() + " | " + "Feed_ID:" + feedId + Constants.RETURN_STRING);
        } catch (Exception ex) {
            Profiler.functionError(info3);
            String errorResp = createErrorResp(Constants.SERVER_UP_DATA,
					Constants.SERVER_ERROR,
					"server error");
            ctx.writeAndFlush(errorResp);
            logger.error("处理设备上传数据失败 feedId:"+feedId+"." + ex.getMessage(), ex);
        } finally {
            Profiler.registerInfoEnd(info3);
        }
    }


    protected void deviceGetInfo(String msg, JSONObject msgJSON, String feedId, CallerInfo info4) {
        deviceControll(msg, msgJSON, feedId, info4);
    }

    protected void deviceControll(String msg, JSONObject msgJSON, String feedId, CallerInfo info2) {
        try {
            //logger.debug(msg);
            Integer serial = null;
            if (msgJSON.containsKey("attribute") && msgJSON.getJSONObject("attribute").containsKey("serial")) {
                serial = msgJSON.getJSONObject("attribute").getInteger("serial");
            }
			Date responsTime = new Date();
			logger.info("response control timestamp:"+ responsTime.getTime()+" feedId:"+feedId+" serial:"+serial);
            ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
            if (null == restClientList) {
                logger.error("rest api channelList is null feedId[" + feedId + "]");
            } else {
                Channel ch = null;
                RestClient temp = null;
                if (null == serial) {
                	CallerInfo serialInfo = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.control.noserial", false, true);
                	Profiler.registerInfoEnd(serialInfo);
                	logger.warn("first version. there is no serial.feedId:"+feedId);
                    temp = restClientList.poll();
                    if (null != temp) {
                        ch = temp.getChannel();
                    }
                } else {
                    temp = restClientList.remove(serial.intValue());
                    if (null != temp) {
                        ch = temp.getChannel();
                    }
                }

                if (ch != null) {
                    ch.writeAndFlush(msg + Constants.RETURN_STRING).addListener(new ChannelFutureListener() {
                        @Override
                        public void operationComplete(ChannelFuture future) throws Exception {
                        }
                    });
                } else {
                    logger.error("rest api channel is null feedId[" + feedId + "]");
                }
            }
            
            calculateTime(msgJSON.getInteger("code"),feedId,serial);
            return;
        } catch (Exception ex) {
            Profiler.functionError(info2);
            logger.error("处理设备控制响应失败 feedId:"+feedId+"." + ex.getMessage(), ex);
            return;
        } finally {
            Profiler.registerInfoEnd(info2);
        }
    }

    protected void heartBeat(ChannelHandlerContext ctx, String msg, JSONObject msgJSON, String feedId, CallerInfo info) {
        JSONObject resp;
        try {
            //logger.debug(msg);         
                 
            redisClient.set(feedId, EventServer.localHost + ":" + EventServer.getRestPort());
            redisClient.expire(feedId, EventServer.redis_expire);
//在缓存中记录设备在线数总数
            String prefix = Constants.CACHE_PREFIX_ONLINE_NUM_HEST;//设备在线数 key的前缀
            String mapKey = Constants.CACHE_PREFIX_FEEDID_PRODUCTID_MAP;//feedId与productId映射表的key
//根据feedId从缓存中获取productId
            Long productId = (Long) EventServer.deviceProduct.get(Long.valueOf(feedId));
            if (null == productId) {
            	String productIdStr = redisClient.hget(mapKey, feedId);
            	if (null != productIdStr) {
            		productId = Long.valueOf(productIdStr);
            		EventServer.deviceProduct.put(Long.valueOf(feedId),productId);
            	}
            }
            		
            if (null != productId) {
                //构造设备在线数在缓存中的key
                String key = prefix+productId;
                redisClient.sadd(key,feedId);    //
            }
            resp = new JSONObject();
            Date nowTime = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_PATTERN);
            resp.put("code", Constants.DEVICE_HEARTBEAT_RESP);
            resp.put("result", Constants.SUCCESS);
            resp.put("time", formatter.format(nowTime));
            resp.put("timestamp", nowTime.getTime()/1000);
            ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
            logger.info("Response Heartbeat to" + ctx.channel().remoteAddress() + " | " + "Feed_ID:" + feedId + Constants.RETURN_STRING);
            return;
        } catch (Exception ex) {
            Profiler.functionError(info);
            String errorResp = createErrorResp(Constants.DEVICE_HEARTBEAT_RESP,
					Constants.SERVER_ERROR,
					"server error");
            ctx.writeAndFlush(errorResp);
            logger.error("处理设备心跳失败.feedId:"+feedId+"."+ ex.getMessage(), ex);
            return;
        } finally {
            Profiler.registerInfoEnd(info);
        }
    }

    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception {
        logger.error("Unexpected exception from downstream.", cause);
    }
    
    public DeviceSafService getDeviceSafService() {
        return deviceSafService;
    }

    public void setDeviceSafService(DeviceSafService deviceSafService) {
        this.deviceSafService = deviceSafService;
    }
    
    protected JSONObject checkMsgFormat(String msg){    	
    	Long feedId = null;
    	Integer code = null;
    	String accessKey = null;
    	try{    		
    		JSONObject msgJson = JSONObject.parseObject(msg);
    		if (null != msgJson){
    			code = msgJson.getInteger("code");
    			feedId = msgJson.getJSONObject("device").getLong("feed_id"); 
    			if (msgJson.getJSONObject("device").containsKey("access_key")) {
                    accessKey = msgJson.getJSONObject("device").getString("access_key");
                } else {
                    accessKey = msgJson.getJSONObject("device").getString("accees_key");
                }
    		}
    		
    		if (null != feedId && null != accessKey && null != code) {
    			return msgJson;
    		} else {
    			return null;
    		}
    	}catch(Exception e){
    		logger.error("exception occur when to cast msg to jsonObject in HttpStreamingHandler" + msg,e);
    		return null;
    	}
    }
    
    protected Long getFeedIdFromMsg(String msg){
    	Long feedId = null;
    	try{    		
    		JSONObject msgJson = JSONObject.parseObject(msg);
    		if (null != msgJson){    			
    			feedId = msgJson.getJSONObject("device").getLong("feed_id");    			
    		}
    	}catch(Exception e){
    		logger.error("exception occur when getFeedIdFromMsg in HttpStreamingHandler" + msg,e);
    	}
    	return feedId;
    }
    
    protected String createErrorResp(int code,int result,String errorMsg){
    	JSONObject errorJson = new JSONObject();
    	errorJson.put("code", String.valueOf(code));
    	errorJson.put("result", String.valueOf(result));
    	errorJson.put("errorMsg", errorMsg);
    	return (errorJson.toJSONString()+Constants.RETURN_STRING);
    }
    
    /*
     * 对设备做校验，只针对两种情况：1、第一次到达的设备；2、重新连接的设备；
     */
	protected boolean authDevice(String feedIdStr, String accessKey,
			ChannelHandlerContext ctx) {
		boolean ret = true;
		if (!EventServer.deviceChannelMap.containsKey(feedIdStr)
				|| ctx.channel() != EventServer.deviceChannelMap.get(feedIdStr)) {
			// 此设备第一次连接到当前eventserver实例
			Message safMessage = deviceSafService.identifyFeed(
					Long.valueOf(feedIdStr), accessKey);
			if (!safMessage.getCode().equals(Constants.SAF_SUCCESS)) {
				String errorResp = createErrorResp(Constants.DEVICE_ERROR,
						Constants.AUTH_FAIL,
						"the accesskey does not match with the feedId");
				if (!Service.isValidConn(ctx.channel())) {
					logger.warn("Auth failed and close connection.Receive Heartbeat from"
							+ ctx.channel().remoteAddress()
							+ " | "
							+ "Feed_ID:"
							+ feedIdStr
							+ "access_key:"
							+ accessKey + Constants.RETURN_STRING);
					ctx.writeAndFlush(errorResp).addListener(
							ChannelFutureListener.CLOSE);
				} else {
					ctx.writeAndFlush(errorResp);
					logger.warn("Auth failed but valid connection.Receive Heartbeat from"
							+ ctx.channel().remoteAddress()
							+ " | "
							+ "Feed_ID:"
							+ feedIdStr
							+ "access_key:"
							+ accessKey + Constants.RETURN_STRING);
				}
				ret = false;
			}
		}
		return ret;
	}
	
	protected void devInfoProcess(String feedId,ChannelHandlerContext ctx){
		if (!EventServer.deviceChannelMap.containsKey(feedId)) {
            EventServer.deviceChannelMap.put(feedId, ctx.channel());
            EventServer.devChannelFeedIdMap.add(ctx.channel(), feedId);
        } else if (ctx.channel() != EventServer.deviceChannelMap.get(feedId)) {
        	logger.info("Channel changed. feedid: " + feedId + ", previous remote address: " + EventServer.deviceChannelMap.get(feedId).remoteAddress() +
                    ", new address: " + ctx.channel().remoteAddress());
            EventServer.devChannelFeedIdMap.erase(EventServer.deviceChannelMap.get(feedId), feedId);
            if (!Service.hasOtherDevConn(EventServer.deviceChannelMap.get(feedId),feedId)) {
                EventServer.deviceChannelMap.get(feedId).close();
            }
            EventServer.deviceChannelMap.put(feedId, ctx.channel());
            EventServer.devChannelFeedIdMap.add(ctx.channel(), feedId);
        }
	}
	
	protected void checkUpgrade(ChannelHandlerContext ctx, String msg,
			JSONObject msgJSON, String feedId, String accessKey, CallerInfo info) {
		JSONObject resp;
		try {
			logger.info("checkUpgrade msg:"+msg);
			if (!msgJSON.containsKey("device"))
				throw new IllegalArgumentException(
						"param[device] is missing...");
			if (StringUtils.isBlank(feedId) || StringUtils.isBlank(accessKey))
				throw new IllegalArgumentException(
						"param feed_id/access_key is missing...");
			Integer firmVersion = msgJSON.getInteger("firm_version");
			if (firmVersion == null) {
				logger.warn("parammeter error,msg:" + msg);
				resp = new JSONObject();
				resp.put("code", Constants.PARAMMETER_ERROR);
				resp.put("errorMsg", "parammeter error");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			Message message = null;
			try {
				message = this.deviceSafService.checkFirmwareUpgradeInfo(
						Long.valueOf(feedId), firmVersion);
			} catch (Exception e) {
				logger.error("checkFirmwareUpgradeInfo failed,msg:" + msg, e);
				resp = new JSONObject();
				resp.put("code", Constants.INTERNAL_SERVER_ERROR);
				resp.put("errorMsg", "server internal error");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			if (message.getCode().equals("6001")) {
				logger.warn(message.getErrorMsg() + ",msg:" + msg);
				resp = new JSONObject();
				resp.put("code", Constants.PRODUCT_UPGRADE_FORBIDDEN);
				resp.put("errorMsg", "product upgrade forbidden");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			if (message.getCode().equals("200")) {
				resp = new JSONObject();
				System.out.println("========message:" + message.toString()
						+ "data:" + message.getData().toString());
				JSONObject safResultJson = JSONObject.parseObject(message
						.getData().toString());
				int needUpgrade = safResultJson.getInteger("need_upgrade");
				resp.put("code", Constants.SERVER_CHECK_UPGRADE_FIRMWARE);
				resp.put("need_upgrade", needUpgrade);
				if (needUpgrade == 1) {
					int latestVersion = safResultJson
							.getInteger("firm_version");
					resp.put("firm_version", latestVersion);
					resp.put("url", safResultJson.getString("url"));
					StringBuffer sb = new StringBuffer();
					sb.append(System.currentTimeMillis()).append("-")
							.append(feedId).append("-").append(latestVersion);
					resp.put("session_id", sb.toString());
					 redisClient.set(sb.toString(), "0");
					 redisClient.expire(sb.toString(),
					 EventServer.session_expire);
				} else {
					resp.put("session_id", null);
					resp.put("url", null);
					resp.put("firm_version", null);
				}
				logger.info("checkUpgrade response:" + resp.toString());
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
		} catch (Exception ex) {
			Profiler.functionError(info);
			ctx.writeAndFlush("{\"code\":" + Constants.INTERNAL_SERVER_ERROR
                    + ",\"result\":" + 0
                    + ",\"errorMsg\":" + "\"server error\""
                    + "}" + Constants.RETURN_STRING);
			logger.error("handle checkUpgrade failed: " + ex.getMessage(), ex);
			return;
		} finally {
			Profiler.registerInfoEnd(info);
		}
	}

	protected void upgradeStatus(ChannelHandlerContext ctx, String msg,
			JSONObject msgJSON, String feedId, String accessKey, CallerInfo info) {
		JSONObject resp;
		SimpleDateFormat formatter = new SimpleDateFormat(
				Constants.DATE_PATTERN);
		try {
			logger.info("upgradeStatus msg:"+msg);
			if (!msgJSON.containsKey("device"))
				throw new IllegalArgumentException(
						"param[device] is missing...");
			if (StringUtils.isBlank(feedId) || StringUtils.isBlank(accessKey))
				throw new IllegalArgumentException(
						"param feed_id/access_key is missing...");
			Integer firmVersion = msgJSON.getInteger("firm_version");
			Integer status = msgJSON.getInteger("status");
			String sessionId = msgJSON.getString("session_id");
			if (firmVersion == null || status == null
					|| StringUtils.isBlank(sessionId)) {
				logger.warn("parammeter error,msg:" + msg);
				resp = new JSONObject();
				resp.put("code", Constants.PARAMMETER_ERROR);
				resp.put("errorMsg", "parammeter error");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			switch (status) {
			case (7001):
				status = 0;
				logger.info("msg:" + msg + " download firmware success");
				break;// download fail
			case (7002):
				status = 1;
				logger.info("msg:" + msg + " download firmware fail");
				break;// download success
			case (7003):
				status = 2;
				logger.info("msg:" + msg + " upgrade firmware success");
				break;// upgrade success
			case (7004):
				status = 3;
				logger.info("msg:" + msg + " upgrade firmware fail");
				break;// upgrade fail
			default:
				status =3;//default fail
				logger.warn("unrecognized status:"+status+" msg:"+msg);	
			}
			 String rvalue=redisClient.get(sessionId);
			 if(StringUtils.isBlank(rvalue)){
			 //session 过期不做逻辑处理直接返回
				 logger.warn("session expired,feedId:"+feedId+",sessionId:"+sessionId);
			 resp = new JSONObject();
			 resp.put("code",Constants.SERVER_UPGRADE_FIRMWARE_STATUS);
			 resp.put("result",0);
			 resp.put("time", formatter.format(new Date()));
			 ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
			 return;
			 }
			Message message = null;
			try {
				message = this.deviceSafService.upgradeStatus(
						Long.valueOf(feedId), firmVersion, status);
			} catch (Exception e) {
				logger.error("upgradeStatus failed,msg:" + msg, e);
				resp = new JSONObject();
				resp.put("code", Constants.INTERNAL_SERVER_ERROR);
				resp.put("errorMsg", "server internal error");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			if (message.getCode().equals("6001")) {
				logger.warn(message.getErrorMsg() + ",msg:" + msg);
				resp = new JSONObject();
				resp.put("code", Constants.PRODUCT_UPGRADE_FORBIDDEN);
				resp.put("errorMsg", "product upgrade forbidden");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			if (message.getCode().equals("200")) {
				resp = new JSONObject();
				resp.put("code", Constants.SERVER_UPGRADE_FIRMWARE_STATUS);
				resp.put("result", 0);
				resp.put("time", formatter.format(new Date()));
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
		} catch (Exception ex) {
			Profiler.functionError(info);
			ctx.writeAndFlush("{\"code\":" + Constants.INTERNAL_SERVER_ERROR
                    + ",\"result\":" + 0
                    + ",\"errorMsg\":" + "\"server error\""
                    + "}" + Constants.RETURN_STRING);
			logger.error("handle upgradeStatus failed: " + ex.getMessage(), ex);
			return;
		} finally {
			Profiler.registerInfoEnd(info);
		}
	}
	protected void commonResp(ChannelHandlerContext ctx, String msg,
			JSONObject msgJSON, String feedId, String accessKey, CallerInfo info) {
		try {
			logger.info("commonResp msg:"+msg);
            ConcurrentList restClientList = EventServer.restChannelMap.get(feedId);
            Integer serial = null;
            if (msgJSON.containsKey("serial")) {
                serial = msgJSON.getInteger("serial");
            }
            if (null == restClientList) {
                logger.error("rest api channelList is null feedId[" + feedId + "]");
            } else {
                Channel ch = null;
                RestClient temp = null;
                if (null == serial) {
                	CallerInfo serialInfo = Profiler.registerInfo("EventServer.handle.HttpStreamingHandler.common.noserial", false, true);
                	Profiler.registerInfoEnd(serialInfo);
                	logger.warn("first version.ota there is no serial.feedId:"+feedId);
                    temp = restClientList.poll();
                    if (null != temp) {
                        ch = temp.getChannel();
                    }
                } else {
                    temp = restClientList.remove(serial.intValue());
                    if (null != temp) {
                        ch = temp.getChannel();
                    }
                }
                if (ch != null) {
                    ch.writeAndFlush(msg + Constants.RETURN_STRING).addListener(new ChannelFutureListener() {
                        @Override
                        public void operationComplete(ChannelFuture future) throws Exception {
                        }
                    });
                } else {
                    logger.error("rest api channel is null feedId[" + feedId + "]");
                }
            }
            return;
        } catch (Exception ex) {
            Profiler.functionError(info);
            ctx.writeAndFlush("{\"code\":" + Constants.INTERNAL_SERVER_ERROR
                    + ",\"result\":" + 0
                    + ",\"errorMsg\":" + "\"server error\""
                    + "}" + Constants.RETURN_STRING);
            logger.error("升级设备控制响应失败 feedId:"+feedId+"." + ex.getMessage(), ex);
            return;
        } finally {
            Profiler.registerInfoEnd(info);
        }
	}
	protected void reportStunInfo(ChannelHandlerContext ctx, String msg,
			JSONObject msgJSON, String feedId, String accessKey, CallerInfo info) {
		JSONObject resp;
		SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_PATTERN);
		try {
			logger.info("reportStunInfo msg:"+msg);
			if (!msgJSON.containsKey("device"))
				throw new IllegalArgumentException(
						"param[device] is missing...");
			if (StringUtils.isBlank(feedId) || StringUtils.isBlank(accessKey))
				throw new IllegalArgumentException(
						"param feed_id/access_key is missing...");
			String sessionId = msgJSON.getString("session_id");
			String mapIp=msgJSON.getString("map_ip");
			int mapPort=msgJSON.getIntValue("map_port");
			String localIp=msgJSON.getString("local_ip");
			int localPort=msgJSON.getIntValue("local_port");
			int natType=msgJSON.getIntValue("nat_type");
			int netType=msgJSON.getIntValue("net_type");
			JSONObject dStunInfo=new JSONObject();
			dStunInfo.put("map_ip", mapIp);
			dStunInfo.put("map_port", mapPort);
			dStunInfo.put("local_ip", localIp);
			dStunInfo.put("local_port", localPort);
			dStunInfo.put("nat_type", natType);
			dStunInfo.put("net_type", netType);
			if (StringUtils.isBlank(sessionId)||StringUtils.isBlank(mapIp)||StringUtils.isBlank(localIp)||natType<0) {
				logger.warn("reportStunInfo parammeter error,msg:" + msg);
				resp = new JSONObject();
				resp.put("code", Constants.PARAMMETER_ERROR);
				resp.put("errorMsg", "parammeter error");
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
				return;
			}
			String appKey=Constants.APP_STUN_PREFIX+feedId+"_"+sessionId;
			String deviceKey=Constants.DEVICE_STUN_PREFIX+feedId+"_"+sessionId; 
			boolean isDeviceStunInfoExist=false;
			int isP2pSupport=-1;
			boolean flag=false;
			int count=0;
			JSONObject appStunInfo=null;
			isDeviceStunInfoExist=redisClient.exists(deviceKey);
			String aStunInfoStr=redisClient.get(appKey);
			if(!isDeviceStunInfoExist){
				redisClient.setex(deviceKey, EventServer.stun_session_expire, dStunInfo.toJSONString());
			}
			while(count<EventServer.stun_max_count){// retry stun_max_count time
				if(!StringUtils.isBlank(aStunInfoStr)){//app stun信息存在马上协商
					appStunInfo=JSONObject.parseObject(aStunInfoStr);
					int appNatType=appStunInfo.getIntValue("nat_type");
					logger.info("start assciate,devNatNat:"+natType+",appNatType:"+appNatType);
					if(natType==0||appNatType==0){
						isP2pSupport=-1;//block situation
					}else{
						isP2pSupport=natType*appNatType<20?0:-1;
					}
					flag=true;
					break;
				}else{
					Thread.sleep(200);//sleep 200 ms to wait astuninfo
					aStunInfoStr=redisClient.get(appKey);
					count++;
				}
			}
			if(flag){//check finish
				resp=new JSONObject();
				appStunInfo.put("p2p_support", isP2pSupport);
				resp.put("code", Constants.REPORT_STUN_INFO_RESP);
				resp.put("result", appStunInfo);
				resp.put("time", formatter.format(new Date()));
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
			}else{
				logger.warn("associate fail,deviceKey:"+deviceKey+",appKey"+appKey);
				resp=new JSONObject();
				resp.put("code", Constants.APP_STUN_INFO_NOT_FOUND);
				resp.put("result", 0);
				resp.put("time", formatter.format(new Date()));
				ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
			}
			logger.info("response to reportStunInfo:"+resp.toJSONString());
		} catch (Exception ex) {
			Profiler.functionError(info);
			ctx.writeAndFlush("{\"code\":" + Constants.INTERNAL_SERVER_ERROR
                    + ",\"result\":" + 0
                    + ",\"errorMsg\":" + "\"server error\""
                    + "}" + Constants.RETURN_STRING);
			logger.error("handle reportStunInfo failed: " + ex.getMessage(), ex);
			return;
		} finally {
			Profiler.registerInfoEnd(info);
		}
	}
	
	protected void reportP2PResult(ChannelHandlerContext ctx, String msg, JSONObject msgJSON, String feedId, CallerInfo info) {
        JSONObject resp;
        try {
            logger.info("reportP2PResult:"+msg);         
            String sessionId=msgJSON.getString("session_id");
            int isConnected=msgJSON.getIntValue("p2p_connect"); // 0表示穿透成功,-1表示穿透失败
            logger.info("sessionId:"+sessionId+",feedId:"+feedId+" connect result:"+isConnected);
            resp = new JSONObject();
            Date nowTime = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_PATTERN);
            resp.put("code", Constants.REPORT_P2P_RESULT_RESP);
            resp.put("result", Constants.SUCCESS);
            resp.put("time", formatter.format(nowTime));
            resp.put("timestamp", nowTime.getTime()/1000);
            ctx.writeAndFlush(resp.toString() + Constants.RETURN_STRING);
            return;
        } catch (Exception ex) {
            Profiler.functionError(info);
            ctx.writeAndFlush("{\"code\":" + Constants.INTERNAL_SERVER_ERROR
                    + ",\"result\":" + 0
                    + ",\"errorMsg\":" + "\"server error\""
                    + "}" + Constants.RETURN_STRING);
            logger.error("handle reportP2PResult failed.feedId:"+feedId+"."+ ex.getMessage(), ex);
            return;
        } finally {
            Profiler.registerInfoEnd(info);
        }
    }

	
	public void calculateTime(int code,String feedId,Integer serial){
		Date now = new Date();
		String method = "";
		String key = "";
		switch(code){
		case 104:
			key = Constants.SERVER_GET_DEVICE_INFO+"#"+feedId+"#"+serial; 
			method = "getStreams";
			break;
		case 102:
			key = Constants.SERVER_CONTROLL+"#"+feedId+"#"+serial; 
			method = "updateStreams";
			break;
		default:
			return;
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
		Long sendTime = (Long)EventServer.expendTime.remove(key);
		
		if (null != sendTime) {
			long period = now.getTime() - sendTime;
			String logInfo = "|||class:"+this.getClass().getName()+"|||controllName:"+method+
					"|||feedId:"+feedId+"|||date:"+sdf.format(now)+"|||dur:"+period+"|||original:eventserver";
			StaticLogger.logInfo(logInfo);
		}
	}
}
