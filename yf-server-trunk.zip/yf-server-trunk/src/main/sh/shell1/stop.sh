#!/bin/bash
PROCESS_PID=`ps aux|grep eventserver |grep "instanceId=1"| grep -v grep| awk '{print $2}'`
if [ $PROCESS_PID -gt 1 ];then
	kill -9 $PROCESS_PID
fi
exit 0