#!/bin/bash
BASE_DIR="$(cd "$(dirname "$0")"; pwd)/../.."
LIB="$BASE_DIR/lib/"
CONFIG="$BASE_DIR/config"
CUSTOM_CONFIG="$BASE_DIR/server2/config"
LOG_DIR="/export/home/apps/logs"
for jar in $LIB/*.*
do
 CLASSPATH=$CLASSPATH:$jar
done

PROCESS_NUM=`ps -ef | grep "eventserver" |grep "instanceId=2"| grep -v "grep" | wc -l`
if [ $PROCESS_NUM -eq 1 ]; then
   echo $1 "process is existed then to kill it firstly!!!"
   PROCESS_PID=`ps aux|grep eventserver |grep "instanceId=2"| grep -v grep| awk '{print $2}'`
   kill -9 $PROCESS_PID
fi

echo "$CONFIG"
CLASSPATH=$CUSTOM_CONFIG:$CONFIG:$CLASSPATH
JAVA_OPT="-server -Xms7168M -Xmx7168M -Xmn2688M -Xss256k -XX:PermSize=128M -XX:MaxPermSize=128M -XX:MaxDirectMemorySize=256M -XX:SurvivorRatio=8 -XX:+UseParallelGC -XX:+UseParallelOldGC -XX:GCTimeRatio=49 -XX:+PrintGCDetails -XX:+PrintGCDateStamps -Xloggc:/export/home/apps/logs/event_server_gc2.log -XX:+HeapDumpOnOutOfMemoryError -XX:ErrorFile=/export/home/apps/logs/event_server__err2.log -XX:HeapDumpPath=/export/home/apps/logs/event_server__dump2.hprof -DinstanceId=2 -Dfile.encoding=UTF-8" 
nohup java $JAVA_OPT -cp ${CLASSPATH} com.jd.smartcloud.eventserver.EventServer &

exit 0
