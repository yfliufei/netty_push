#!/bin/bash
BASE_DIR="$(cd "$(dirname "$0")"; pwd)/.."
LIB="$BASE_DIR/lib/"
CONFIG="$BASE_DIR/config"
LOG_DIR="/export/home/apps/logs"
for jar in $LIB/*.*
do
 CLASSPATH=$CLASSPATH:$jar
done

PROCESS_NUM=`ps -ef | grep "eventserver" | grep -v "grep" | wc -l`
if [ $PROCESS_NUM -eq 1 ]; then
   echo $1 "process is existed then to kill it firstly!!!"
   PROCESS_PID=`ps aux|grep eventserver | grep -v grep| awk '{print $2}'`
   kill -9 $PROCESS_PID
fi

echo "$CONFIG"
CLASSPATH=$CONFIG:$CLASSPATH
JAVA_OPT="-server -Xms1024M -Xmx1024M -Xmn384M -Xss256k -XX:PermSize=128M -XX:MaxPermSize=128M -XX:MaxDirectMemorySize=256M -XX:SurvivorRatio=8 -XX:+UseParallelGC -XX:+UseParallelOldGC -XX:GCTimeRatio=49 -XX:+PrintGCDetails -XX:+PrintGCDateStamps -Xloggc:/export/home/apps/logs/event_server_gc.log -XX:+HeapDumpOnOutOfMemoryError -XX:ErrorFile=/export/home/apps/logs/event_server__err.log -XX:HeapDumpPath=/export/home/apps/logs/event_server__dump.hprof" 
nohup java $JAVA_OPT -cp ${CLASSPATH} com.jd.smartcloud.eventserver.EventServer &

exit 0
